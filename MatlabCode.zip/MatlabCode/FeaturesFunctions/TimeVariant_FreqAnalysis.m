function [out_vars] = TimeVariant_FreqAnalysis(time,data,fs,typePsd,freq_vec,freq_bands, window_samp,jump_samp,display)


if nargin<9,
    
    display = 0;
end

if nargin<8,
    jump_samp = floor(0.05*20*fs); %% 1 second jump
end

if nargin<7,
    window_samp = floor(20*fs); %% 20 seconds window
    
end

if nargin<6,
    freq_bands = 0:0.1:1; %% frequency bands with 0.1 Hz intervals from 0 to 1 Hz
    
end

if nargin<5
    freq_vec = 0:0.01:1;
end

if nargin<4
    typePsd = 0;
end

if nargin<3
    
    psd = [];
    psd_time = [];
    psd_freq = [];
    aT = [];
    aP = [];
    RaP = [];
    warning('Missing inputs')
    return;
end


    psd = [];
    psd_time = [];
    psd_freq = [];
    aT = [];
    aP = [];
    RaP = [];
    
    pT = [];
    pP = [];
    RpP = [];
    
half_window_samp = floor(window_samp/2)-1;
N_data = length(data);


psd = []; 
psd_time = []; 
psd_freq = [];

aT = [];
aT_interval_Hz(1:2) = [freq_bands(1), freq_bands(end)];

aP = [];
aP_interval_Hz = [];

for i=1:length(freq_bands)-1,
aP_interval_Hz(i,:) = [freq_bands(i) freq_bands(i+1)];
end

best_order = [];

N_res = length(1:jump_samp:N_data);

k=0;
%keyboard;
% for i=1:jump_samp:N_data-1
for i=1:jump_samp:N_data-half_window_samp

    
     k=k+1;
    ind_b = i-half_window_samp; 
    ind_a = i+half_window_samp; 
    
    zero_pading_b = [];
    zero_pading_a = [];
    
   

    psd (:,k) = ones(length(freq_vec),1)*nan; 
    psd_freq = nan;

    aT(1,k) = nan; 
    aP(1:length(freq_bands)-1,k) = nan;
    RaP(1:length(freq_bands)-1,k) = nan;

    pT(1,k) = nan; 
    pP(1:length(freq_bands)-1,k) = nan;
    RpP(1:length(freq_bands)-1,k) = nan;
    
    psd_time(k) = time(ind_a);
    
    
    if ind_b<1
        continue;
        ind_b=1; 
    end
    
    if ind_a>N_data
        continue;
        ind_a=N_data; 
    end
    data_i = data(ind_b:ind_a);

    best_order = 16; %% Calculated one time using arburg --> 
                        %https://www.mathworks.com/help/signal/ug/ar-order-selection-with-partial-autocorrelation-sequence.html

    out = PupilFreqAnalysis(data_i, fs, typePsd, best_order, freq_vec,freq_bands,display); 

    
    psd_freq = out.psd_freq;
    psd (:,k) = out.psd; 


    aT(1,k) = out.aT; 
    aP(:,k) = out.aP;
    RaP(:,k) = out.RaP;
    
    pT(1,k) = out.pT; 
    pP(:,k) = out.pP;
    RpP(:,k) = out.RpP;

end

out_vars.psd_time = psd_time;
out_vars.psd_freq = psd_freq;
out_vars.psd = psd;
out_vars.aT = aT;
out_vars.aP = aP;
out_vars.RaP = RaP;
out_vars.pT = pT;
out_vars.pP = pP;
out_vars.RpP = RpP;

end

function [out] = PupilFreqAnalysis(data, data_fs, typePsd, ord, freq_vec,freq_bands, display) 

if nargin<7,
    
    display = 0;
end

if nargin<6,
    freq_bands = 0:0.1:1; %% frequency bands with 0.1 Hz intervals from 0 to 1 Hz
    
end

if nargin<5
    freq_vec = 0:0.01:1;
end

if nargin==0
    ecgWarning('Error: input should be a data vector','hrvTimeDomain');
    out=[];
    return
end


psd = []; 
psd_freq = [];

aT = []; 
aP = [];

N = length(data);
Rwind=blackman(N);   
data= detrend(data);
data=data(:);


Rwind=Rwind(:);
data=(data-mean(data)).*Rwind;       


%Hannign
%%
if N<freq_bands(end)*data_fs,
    half_zero = floor(((freq_bands(end)*data_fs)-N+1)/2);
    data = [zeros(half_zero,1); data; zeros(half_zero,1)];
%     keyboard;
end
%%
%------------------------------------------------------ PSD 
W = freq_vec;
if typePsd==0
    par=0.25;
    ord=min(ord, fix(par*length(data)) );
%     keyboard;
    [P,F]=pburg(data,ord,W,data_fs);
end
if typePsd==1
    [P,F]=pwelch(data,[],[],W,data_fs);
end
if typePsd==2
    [P,F]=pmusic(data,16,W,data_fs);
end

%------------------------------------------------------ LFHF
% The LF and HF are defined as [0.04, 0.15] and [0.15, 0.4] respectively.
i_freqs = {};
for i=1:length(freq_bands)-1
    i_freqs{i} = find(F>freq_bands(i) & F<=freq_bands(i+1));
end


pT = max(P);
aT = sum(P); 

for i=1:length(freq_bands)-1
   aP(i,1) =  sum(P(i_freqs{i}));
   pP(i,1) = max(P(i_freqs{i}));
end

RaP = aP/aT;
RpP = pP/pT;



out.psd = P; 
out.psd_freq = F;

out.aT = aT; 
out.aP = aP; 
out.RaP = RaP; 

out.pT = pT; 
out.pP = pP; 
out.RpP = RpP; 

if display
    figure(1);
    clf

    plot(F,P,'g')

    xlim([0 freq_bands(end)])
pause(0.01);
end
end

