%ECG_Window_Segmentation of ecg signal. Detection of QRS peaks, Q
%wave onset and S wave offset, without iterations
%
%[WAVES_FOUND,PRESIGNAL,CORR_COEF_PWAVES] = ECG_WINDOW_SEGMENTATION(ECG,SAMPLE_FREQ)
%
%   ECG is ECG signal matrix (2 columns - indexes and values of ecg samples)
%   SAMPLE_FREQ is the ecg signal sampling frequency
%
%   The outputs are:
%   WAVES_FOUND is matrix containing the indexes vectors corresponding to
%   onset, peak and offset of the P, QRS and T waves in the following order
%   ([ponset ppeak poffset qonset qpeak rpeak speak soffset tonset tpeak toffset])
%   NOTE: Absent waves are displayed with the index zero;
%   PRESIGNAL ecg signal without  noise and without baseline drifts,
%   unnormalized
%   CORR_COEF_PWAVES is a vector indicating the correlation coeficient of
%   each P wave with an ideal Pwave model

function [Waves_Found,preSignal,Corr_Coef_Pwaves] = ECG_Segmentation_Local_Window(ECG,Sample_Freq)

%-------------------------------------------------------------------------%
if nargin<2,
    Sample_Freq=250;
end

if size(ECG,2)==1
    ECG(:,2)=ECG(:,1);
    ECG(:,1)=1:1:length(ECG);
elseif size(ECG,2)>2
    error('ECG must be a matrix with indexes and ECG values (n lines and two columns)');
end
%-------------------------------------------------------------------------%

%-------------------------------------------------------------------------%
ECG_Segmentation_root=mfilename('fullpath');
ECG_Segmentation_root=ECG_Segmentation_root(1:end-length(mfilename));


%Elimina��o do ru�do------------------------------------------------------%
[f_ns,N_f_ns] = Noise_Supression(ECG);
%-------------------------------------------------------------------------%


%Elimina��o das flutua��es da linha de base-------------------------------%
Bo_length=round(0.2*Sample_Freq);if Bo_length/2==round(Bo_length/2),Bo_length=Bo_length+1; end
Bo=zeros(Bo_length,1);
[f,N_f] = Base_Line_Drift_Supression(f_ns,N_f_ns,Bo);

preSignal=f(:,2);

%-Normaliza��o do sinal pr�-processado------------------------------------%
f(:,2)=f(:,2)/(max(f(:,2))-min(f(:,2)));
%-------------------------------------------------------------------------%



%Calculo da derivada morfologica em v�rias escalas------------------------%

%-Calculo da derivada utilizada na detec��o dos complexos QRS-------------%
Scale=round(Sample_Freq*0.035);
Mfd_QRS= Morphological_Derivative(f(:,2),N_f,Scale);
N_Mfd_QRS=length(Mfd_QRS);

%-Calculo da derivada utilizada na detec��o das ondas T-------------------%
Scale=round(Sample_Freq*0.09);
Mfd_T= Morphological_Derivative(f(:,2),N_f,Scale);
N_Mfd_T=length(Mfd_T);

%-Calculo da derivada utilizada na detec��o das ondas P-------------------%
Scale=round(Sample_Freq*0.055);
Mfd_P= Morphological_Derivative(f(:,2),N_f,Scale);
N_Mfd_P=length(Mfd_P);
%-------------------------------------------------------------------------%



%Detec��o das ons Q,R,S---------------------------------------------------%
[Complex_Indices,Positive_Complex]=QRS_Detection(f,Mfd_QRS,N_Mfd_QRS,Sample_Freq);
%-------------------------------------------------------------------------%



%Detectar os limites dos complexos QRS------------------------------------%
Qon_Soff=qon_soff_detection(Mfd_T,N_Mfd_T,Sample_Freq, ...
    Complex_Indices,Positive_Complex);
%-------------------------------------------------------------------------%


%Detectar as ondas T------------------------------------------------------%
[T_on_off] = Twave_Detection(f(:,2),Mfd_T,...
    N_Mfd_T,Qon_Soff,Complex_Indices,Sample_Freq,ECG_Segmentation_root);
clear Mfd_T
%-------------------------------------------------------------------------%


%Detectar as ondas P------------------------------------------------------%
[P_on_off,Q_on,Corr_Coef_Pwaves] = Pwave_Detection(f(:,2),Mfd_P,...
    N_Mfd_P,Qon_Soff,Complex_Indices,T_on_off,Sample_Freq,ECG_Segmentation_root);
Qon_Soff(:,1)=Q_on;
clear Mfd_P
%-------------------------------------------------------------------------%


%-------------------------------------------------------------------------%
%Cria��o de uma matriz com os indices das ondas todas---------------------%
Waves_Found=[P_on_off Qon_Soff(:,1) Complex_Indices Qon_Soff(:,2) T_on_off];
%-------------------------------------------------------------------------%

 
