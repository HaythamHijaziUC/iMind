%--------------------------------------------------------------------------
% Function that calculates R peak height 
%--------------------------------------------------------------------------

function Rh = CalculateRh(ECG,SampleFreq,WAVES_FOUND)

Rh=zeros(length(WAVES_FOUND),1);

for i=1:length(Rh)
    if WAVES_FOUND(i,6)~=0 && ECG(WAVES_FOUND(i,6))>0 
        Rh(i)=ECG(WAVES_FOUND(i,6));    % Exclude non-positive values 
    end
end