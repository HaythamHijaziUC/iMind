%--------------------------------------------------------------------------
% Function that calculates the Q peak height and Q wave width 
% -> Q width measured from the Q onset to Q peak
%
%--------------------------------------------------------------------------

function [Qh,Qw] = CalculateQhQw(ECG,SampleFreq,WAVES_FOUND)

%Q peak height: 
Qh=zeros(length(WAVES_FOUND),1);

for i=1:length(Qh)
    if WAVES_FOUND(i,5)~=0 && ECG(WAVES_FOUND(i,5))<0   
        Qh(i)=ECG(WAVES_FOUND(i,5));    % Exclude non-negative values
    end
end

%Q wave width: 
Qw=zeros(length(WAVES_FOUND),1);
  
for i=1:length(Qw)
    if WAVES_FOUND(i,4)~=0 && WAVES_FOUND(i,5)~=0
        Qw(i)=WAVES_FOUND(i,5)-WAVES_FOUND(i,4);
    end
end

% Convert to seconds:
Qw=Qw/SampleFreq;


