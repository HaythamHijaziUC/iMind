%--------------------------------------------------------------------------
% Function that calculates corrected JT interval
% -> JT - distance from the J point to the end of T
% -> Corrected JT: JTc = JT/sqrt(RR)
%--------------------------------------------------------------------------

function JTc = CalculateJTc(ECG,SampleFreq,WAVES_FOUND)

% Vector of R peaks:
RPeaks=WAVES_FOUND(:,6);     

% Calculate RR average distance:
AVG_RR=0;
count=0;
for i=1:length(RPeaks)-1
    AVG_RR = AVG_RR + (RPeaks(i+1)-RPeaks(i));
    count=count+1;
end
AVG_RR=AVG_RR/count;

JT=zeros(length(WAVES_FOUND),1);     
for i=1:length(JT)
    if WAVES_FOUND(i,11)~=0 && WAVES_FOUND(i,8)~=0
        JT(i)=WAVES_FOUND(i,11)-WAVES_FOUND(i,8);
    end
end

% Convert to seconds:
JT=JT/SampleFreq;

% Calculate corrected JT:
JTc=JT/sqrt(AVG_RR);
