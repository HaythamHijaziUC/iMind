%--------------------------------------------------------------------------
% Function that calculates QRS duration
%--------------------------------------------------------------------------

function QRS = CalculateQRS(ECG,SampleFreq,WAVES_FOUND)

QRS=zeros(length(WAVES_FOUND),1);     
for i=1:length(QRS)
    if WAVES_FOUND(i,8)~=0 && WAVES_FOUND(i,4)~=0
        QRS(i)=WAVES_FOUND(i,8)-WAVES_FOUND(i,4);
    end
end

% Convert to seconds:
QRS=QRS/SampleFreq;