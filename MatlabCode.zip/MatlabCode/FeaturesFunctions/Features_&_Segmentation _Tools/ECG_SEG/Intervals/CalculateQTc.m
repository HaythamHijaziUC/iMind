%--------------------------------------------------------------------------
% Function that calculates corrected QT interval
% ->  QT measured from the onset of the Q wave until the termination of the
%     T wave
% ->  Corrected QT: QTc = QT/sqrt(RR)
%--------------------------------------------------------------------------

function QTc = CalculateQTc(ECG,SampleFreq,WAVES_FOUND)

% Vector of R peaks:
RPeaks=WAVES_FOUND(:,6);     

% Calculate RR average distance:
AVG_RR=0;
count=0;
for i=1:length(RPeaks)-1
    AVG_RR = AVG_RR + (RPeaks(i+1)-RPeaks(i));
    count=count+1;
end
AVG_RR=AVG_RR/count;

% Convert to seconds:
AVG_RR=AVG_RR/SampleFreq;

% Calculate QT interval:
QT=zeros(length(WAVES_FOUND),1);

for i=1:length(QT)
    if WAVES_FOUND(i,4)~=0 && WAVES_FOUND(i,11)~=0
        QT(i)=WAVES_FOUND(i,11)-WAVES_FOUND(i,4);
    end
end

% Convert to seconds:
QT=QT/SampleFreq;

% Calculate corrected QT:
QTc=QT/sqrt(AVG_RR);