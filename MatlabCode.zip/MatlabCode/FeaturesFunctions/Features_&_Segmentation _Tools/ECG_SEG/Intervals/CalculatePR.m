%--------------------------------------------------------------------------
% Function that calculates PR interval
% ->  Distance between the onset of P wave and the onset of Q wave 
%--------------------------------------------------------------------------

function PR = CalculatePR(ECG,SampleFreq,WAVES_FOUND)

PR=zeros(length(WAVES_FOUND),1);       
for i=1:length(PR)
    if WAVES_FOUND(i,1)~=0 && WAVES_FOUND(i,4)~=0
        PR(i)=WAVES_FOUND(i,4)-WAVES_FOUND(i,1);
    end
end

% Convert to seconds:
PR=PR/SampleFreq;
