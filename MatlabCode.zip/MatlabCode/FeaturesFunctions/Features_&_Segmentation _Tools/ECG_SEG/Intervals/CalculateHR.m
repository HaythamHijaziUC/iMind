%--------------------------------------------------------------------------
% Function that calculates Heart Rate 
% -> Number of QRS complexes in a minute
%--------------------------------------------------------------------------

function HR = CalculateHR(ECG,SampleFreq,WAVES_FOUND)

RPeaks=WAVES_FOUND(:,6);                   % Vector of R peaks
NumQRS=0;
for i=1:length(RPeaks)
    if RPeaks(i)~=0
        NumQRS=NumQRS+1;
    end
end

InMinutes=(length(ECG)/SampleFreq)/60;     % ECG duration in minutes
HR=round(NumQRS/InMinutes);