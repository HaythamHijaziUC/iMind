%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%Detec��o das ondas Q, R, S%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%--------------INPUT------------------------------------------------------%
%f0 - janela ECG original
%N_f0 - tamanho da janela
%f - janela ECG j� pr�-processada
%N_f - Tamanho da janela
%Mfd - Derivada morfologica
%N_Mfd - Tamanho da janela da derivada morfologica
%Qon_Soff - Lintes do complexo QRS
%Complex_Indices - Indices dos complexos QRS
%T_on_off - 
%Sample_Freq - frequencia de amostragem
%Reading_Window - Janela do ECG
%ECG_Segmentation_root - Caminho da fun��o ECG_Segmentation
%DISPLAY - 0 ou 1 - mostrar grafico ou n�o
%--------------OUTPUT-----------------------------------------------------%
%T_on_off - Indices das ondas T
%Twaves_Selection - Indices das ondas T que obecem ao limiar de correla��o
%-------------------------------------------------------------------------%



function [P_on_off,Q_on,Corr_Coef_Pwaves] = Pwave_Detection(f,Mfd,...
    N_Mfd,Qon_Soff,Complex_Indices,T_on_off,Sample_Freq,...
    ECG_Segmentation_root)


%-------------------------------------------------------------------------%
%Carregar o modelo da onda T----------------------------------------------%
Pwave_Model_root=[ECG_Segmentation_root 'PTWaveModels/'];
load([Pwave_Model_root 'Ideal_Pwave_Models.mat']);
%-------------------------------------------------------------------------%


%-------------------------------------------------------------------------%
%Inicializa��o de variaveis-----------------------------------------------%
Q_on=Qon_Soff(:,1);
N_Q_on=length(Q_on);
S_off=Qon_Soff(:,2);
N_S_off=length(S_off);
Q_peak=Complex_Indices(:,1);
% S_peak=Complex_Indices(:,3);
% R_peak=Complex_Indices(:,2);

Wave_Interval=round((Sample_Freq*0.2)/4);
%-------------------------------------------------------------------------%


%-------------------------------------------------------------------------%
%Enocontrar amplitude da onda P modelo------------------------------------%
% Pwave_Avrg(:,1)=positive_Pwave_model;
% N_Pwave_average=length(Pwave_Avrg);
% Min_Pwave_Avrg=min([Pwave_Avrg(1) Pwave_Avrg(end)]);
% [Max_Pwave_Avrg x_max_Pwave_average]=max(Pwave_Avrg);
% Amp_Pwave_Avrg=Max_Pwave_Avrg-Min_Pwave_Avrg;
%-------------------------------------------------------------------------%

%-------------------------------------------------------------------------%
%Calculo dos limiares positivo e negativo---------------------------------%
Mfd_pos=Mfd(Mfd>=0);
% Mfd_pos=Mfd(find(Mfd>=0));
th1=mean(Mfd_pos)*0.05;
Mfd_neg=Mfd(Mfd<0);
% Mfd_neg=Mfd(find(Mfd<0));
th2=mean(Mfd_neg)*0.05;
%-------------------------------------------------------------------------%


P_on_off=zeros(N_Q_on,3);
Corr_Coef_Pwaves=zeros(N_Q_on,1);


for i=1:N_Q_on
    
%-------------------------------------------------------------------------%    
%---Calculo do intervalo de procura da onda P-----------------------------%     
    if i==1,
        Interval_Before=Q_peak(i,1)-round(0.3*Sample_Freq);
        if Interval_Before<1, Interval_Before=1; end
    else

        int=Q_peak(1:i-1,1)-P_on_off(1:i-1,1);
        int=int(int(:,1)~=0,:);
%         int=int(find(int(:,1)~=0),:);
        N_int=length(int);
        if N_int>0,
            mean_int=round(mean(int));
            if mean_int>0
                Interval_Before=Q_peak(i,1)-round(mean(int)+0.1*Sample_Freq);
            else
                Interval_Before=Q_peak(i,1)-round((Q_peak(i,1)-S_off(i-1))*0.6); 
            end
        else
            Interval_Before=Q_peak(i,1)-round((Q_peak(i,1)-S_off(i-1))*0.6);
        end
        if Interval_Before<T_on_off(i-1,3)
            Interval_Before=T_on_off(i-1,3)-round(0.05*Sample_Freq); 
        elseif Interval_Before<T_on_off(i-1,3) && Interval_Before<Soff(i-1,1) %Alterei Soff(i-1,3) para Soff(i-1,1)
            Interval_Before=Soff(i-1,3);
        end
    end


    Interval_After=Q_peak(i,1)+1;
%-------------------------------------------------------------------------%


%-------------------------------------------------------------------------%
%---Calculo de maximos e minimos locais da derivada-----------------------%
    Sense=round(0.0075*Sample_Freq); %sensibilidade de procura dos maxs e mins locais
    b=Mfd(Interval_Before:Interval_After);
    
    Maximums_L1=Local_Max(b,Sense,Interval_Before);
    Maximums_L1=Maximums_L1(Maximums_L1(:,2)>=th1,:); %maximos locais t�m que ser maiores do que th1
%     Maximums_L1=Maximums_L1(find(Maximums_L1(:,2)>=th1),:);
    %     N_Maximums_L1=size(Maximums_L1,1);

    Maximums_L2=Local_Max(b,round(Sense*1.5),Interval_Before);
    Maximums_L2=Maximums_L2(Maximums_L2(:,2)>=th1,:); %maximos locais t�m que ser maiores do que th1
%     Maximums_L2=Maximums_L2(find(Maximums_L2(:,2)>=th1),:);
    %     N_Maximums_L2=size(Maximums_L2,1);
    
    Minimums_L2=Local_Min(b,round(Sense*1.5),Interval_Before);
    Minimums_L2=Minimums_L2(Minimums_L2(:,2)<=th2,:); %minimos locais t�m que ser menores do que th2
%     Minimums_L2=Minimums_L2(find(Minimums_L2(:,2)<=th2),:);
    N_Minimums_L2=size(Minimums_L2,1);
%-------------------------------------------------------------------------%


%-------------------------------------------------------------------------%
%Calculo dos maximos e minimos do sinal f---------------------------------%
    b=f(Interval_Before:Interval_After);
    Maximums_f=Local_Max(b,Wave_Interval,Interval_Before);
    Maximums_f=Maximums_f(Maximums_f(:,2)>0.03,:);
%     Maximums_f=Maximums_f(find(Maximums_f(:,2)>0.03),:);    
%     N_Maximums_f=size(Maximums_f,1);
%-------------------------------------------------------------------------%


%-------------------------------------------------------------------------%
%---Calcular janelas de selec��o de conjuntos caracteristicos-------------%
    Search_Window=[];
    Search_Window(:,1)=Maximums_f(:,1)-round(0.07*Sample_Freq); 
    Search_Window(:,2)=Maximums_f(:,1)+round(0.07*Sample_Freq);
    Search_Window=Search_Window(Search_Window(:,1)>0 & Search_Window(:,2)<N_Mfd,:);
%     Search_Window=Search_Window(find(Search_Window(:,1)>0 & Search_Window(:,2)<N_Mfd),:);   
    N_Search_Window=size(Search_Window,1);
    
%-------------------------------------------------------------------------%



%-------------------------------------------------------------------------%
%---Encontrar conjuntos caracteristicos-----------------------------------%
    P=zeros(N_Minimums_L2,3);
    for j=1:N_Minimums_L2
        ind_max_antes=find(Maximums_L2(:,1)<Minimums_L2(j,1));
        N_ima=length(ind_max_antes);
        ind_max_depois=find(Maximums_L1(:,1)>Minimums_L2(j,1));
        N_imd=length(ind_max_depois);
        
%%% Esta mal!!!--P_on_off(i,1:3)=Interval_After;
%         if N_ima==0 || N_imd==0, P_on_off(i,1:3)=Interval_After; continue; end
%               P(j,1)=Maximums_L2(ind_max_antes(end),1); 
        if N_ima==0, 
            P(j,1)=Interval_Before; 
        else
            P(j,1)=Maximums_L2(ind_max_antes(end),1);
        end
        
        P(j,2)=Minimums_L2(j,1);
        
%%%  Esta mal!!!--P_on_off(i,1:3)=P(j,3)=S_off(i-1,1);      
%         if N_imd==0, if i<N_S_off, P(j,3)=S_off(i-1,1); else P(j,3)=length(Mfd); end
%         else P(j,3)=Maximums_L1(ind_max_depois(1),1);
%         end
        if N_imd==0, if i<N_S_off, P(j,3)=Interval_After; else P(j,3)=length(Mfd); end
        else P(j,3)=Maximums_L1(ind_max_depois(1),1);
        end
    end

    N_P=size(P,1); 

    if N_P==0, P_on_off(i,1:3)=Interval_After-1; continue; end
%-------------------------------------------------------------------------%    


%-------------------------------------------------------------------------%
%---Selecionar consoante as janelas de selec��o encontradas---------------%
    k=0;
%     ind_sel=[];
    ind_ext=[];
    for j=1:N_Search_Window
       ind_sel=find(P(:,2)<Search_Window(j,2) & P(:,2)>Search_Window(j,1));
       N_is=length(ind_sel);
       if N_is>0, k=k+1;  ind_ext(k:k+N_is-1)=ind_sel; k=k+N_is-1; end

    end
    N_ie=size(ind_ext,1);

    if N_ie>0, P=P(ind_ext,:); else P_on_off(i,1:3)=Interval_After-1; continue; end
%     N_P=size(P,1);
%-------------------------------------------------------------------------%

    N_P=size(P,1);
    if N_P==0, P_on_off(i,1:3)=Interval_After-1; continue; end
    
    P=P((Mfd(P(:,1))>0 & Mfd(P(:,2))<0 & Mfd(P(:,3))>0) | ...
            (Mfd(P(:,1))<0 & Mfd(P(:,2))>0 & Mfd(P(:,3))<0),:); 
%     P=P(find((Mfd(P(:,1))>0 & Mfd(P(:,2))<0 & Mfd(P(:,3))>0) | ...
%             (Mfd(P(:,1))<0 & Mfd(P(:,2))>0 & Mfd(P(:,3))<0)),:); 
    N_P=size(P,1);
    if N_P==0, P_on_off(i,1:3)=Interval_After-1; continue; end


% %-------------------------------------------------------------------------%        
% %---Excluir conjuntos caracteristicos que n�o correspondam aos padroes----%    
%     P_length=P(:,3)-P(:,1);
%     ind=find(P_length>0.06*Sample_Freq & P_length<0.28*Sample_Freq);
%     P=P(ind,:);
%     
% %     N_P=size(P,1);
% %     if N_P==0, P_on_off(i,1:3)=Interval_After-1; continue; end
% %     min_P=min([f0(P(:,1)) f0(P(:,3))]);
% %     P_amplitude=max(f0(P(:,1):P(:,3)))-min_P;
% %     ind=find(P_amplitude<217 & P_amplitude>1.95);
% %     P=P(ind,:);
%     
%     N_P=size(P,1);
%     if N_P==0, P_on_off(i,1:3)=Interval_After-1; continue; end
% %-------------------------------------------------------------------------%


%-------------------------------------------------------------------------%
%Encontar indices morfologicos C e D--------------------------------------%
    for k=1:N_P
        if P(k,1)~=P(k,3)
            Line=interp1([P(k,1) P(k,3)],[f(P(k,1)) f(P(k,3))],P(k,1):1:P(k,3))';
            Wave_Transf=f(P(k,1):P(k,3))-Line;
%             lnt=sqrt((f(P(k,3))-f(P(k,1)))^2+length(P(k,1):1:P(k,3))^2);
%             P(k,4)=(sum(Wave_Transf)/lnt)*max(Wave_Transf);
            P(k,4)=(sum(Wave_Transf)/length(P(k,1):1:P(k,3)))*max(Wave_Transf);
            
            Pwave_Avrg=[];
            Pwave_Avrg(:,1)=positive_Pwave_model;
            N_Pwave_average=length(Pwave_Avrg);
            [Max_Pwave_Avrg x_max_Pwave_average]=max(Pwave_Avrg);
            Pwave=f(P(k,1):P(k,3));
            N_Pwave=length(Pwave);
            dif_N=N_Pwave-N_Pwave_average;
            if dif_N<0,
%                 Pwave_aux=zeros(abs(dif_N)+N_Pwave,1);
%                 Pwave_aux(1:abs(dif_N),1)=Pwave(1);
%                 Pwave_aux(abs(dif_N)+1:end,1)=Pwave;
%                 Pwave=Pwave_aux;
                Pwave=[ones(abs(dif_N),1)*Pwave(1); Pwave];
            else
%                 Pwave_Avrg_aux=zeros(abs(dif_N)+N_Pwave_average,1);
%                 Pwave_Avrg_aux(1:abs(dif_N),1)=Pwave_Avrg(1);
%                 Pwave_Avrg_aux(abs(dif_N)+1:end,1)=Pwave_Avrg;
%                 Pwave_Avrg=Pwave_Avrg_aux;
                Pwave_Avrg=[ones(dif_N,1)*Pwave_Avrg(1); Pwave_Avrg];
                x_max_Pwave_average=x_max_Pwave_average+dif_N;
            end
%             N_Pwave=length(Pwave);

            [max_Pwave x_max_P_wave]=max(Pwave);
            dif_max=x_max_P_wave-x_max_Pwave_average;
            if dif_max>0,
%                 Pwave_aux=[Pwave;ones(dif_max,1)*Pwave(end)];
%                 Pwave=Pwave_aux(dif_max+1:end);
                Pwave=[Pwave;ones(dif_max,1)*Pwave(end)];
                Pwave(1:dif_max)=[];
            elseif dif_max<0,
%                 Pwave_aux=[ones(abs(dif_max),1)*Pwave(1);Pwave];
%                 Pwave=Pwave_aux(1:end+dif_max);
                Pwave=[ones(abs(dif_max),1)*Pwave(1);Pwave];
                Pwave(end+dif_max+1:end)=[];
            end
            coef_corr_Pwave=corrcoef(Pwave_Avrg,Pwave);
            
            if (isnan(coef_corr_Pwave(1,2))==1)
                P(k,5)=0;
            else
                P(k,5)=abs(coef_corr_Pwave(1,2));%% Alterei isto para abs...
            end
        else
            P(k,4)=0; P(k,5)=0;
        end
    end


    
            
            


    N_P=size(P,1);
%-------------------------------------------------------------------------%

    P(:,6)=(1:1:N_P)';
    

%-------------------------------------------------------------------------%
%---Selecionar onda P com base nos coeficientes C e D---------------------%
    if N_P>=2
        P_par1=sortrows(P,4);
        ind1=P_par1(end-1:end,6);
        P_par2=sortrows(P,5);
        ind2=P_par2(end-1:end,6);
        if ind1(2)==ind2(2),
            P=P(ind1(2),:);            
        else 
            P=P([ind1(2) ind2(2)],:);
            P=sortrows(P,5);
            corr_cmp=P(2,5)-P(1,5);
            if corr_cmp>0.1,
                P=P(2,:);
            else
                P=sortrows(P,2);
                P=P(2,:);
            end
        end
    elseif N_P==0,
        P_on_off(i,1:3)=Interval_After+1; continue;
    end

    Corr_Coef_Pwaves(i,1)=P(1,5);
%-------------------------------------------------------------------------%  



    P_on_off(i,1:3)=P(1:3);

    if P_on_off(i,3)>=Q_on(i,1), Q_on(i,1)=P_on_off(i,3); end

    clear Search_Window P a b c Maximums_f ind_sel ind_ext;
    
end 


% Pwaves_Selection=[];
% diffMaxTemplate_Pwaves=[];
% 
% try
%     CorrVal_tolerance=0.1;
%     maxCorrVal=max(Corr_Coef_Pwaves);
%     diffMaxTemplate_Pwaves=maxCorrVal-Corr_Coef_Pwaves;
%     Pwaves_Selection=find(diffMaxTemplate_Pwaves<CorrVal_tolerance & Corr_Coef_Pwaves>0);
% catch
% end


