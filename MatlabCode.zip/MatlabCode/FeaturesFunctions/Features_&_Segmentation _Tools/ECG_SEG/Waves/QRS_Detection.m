%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%Detec��o das ondas Q, R, S%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%--------------INPUT------------------------------------------------------%
%f - janela ECG j� pr�-processada
%N_f - Tamanho da janela
%Mfd - Derivada morfologica
%N_Mfd - Tamanho da janela da derivada morfologica
%Sample_Freq - frequencia de amostragem
%DISPLAY - 0 ou 1 - mostrar grafico ou n�o
%--------------OUTPUT-----------------------------------------------------%
%Complex_Indices - Indices das Ondas Q,R,S
%Positive_Complex - Boolean que informa se o complexo � positivo ou n�o (1 ou 0)
%-------------------------------------------------------------------------%

function varargout = QRS_Detection(f,Mfd,N_Mfd,Sample_Freq)

%-------------------------------------------------------------------------%
%Calculo do Histograma da derivada morfologica----------------------------%
Sampling=(max(Mfd(:,1))-min(Mfd(:,1)))/99;
Values_Mfd=min(Mfd(:,1)):Sampling:max(Mfd(:,1));
Hist_Mfd(:,1)=hist(Mfd(:,1),Values_Mfd);
% N_his_Mfd=length(Hist_Mfd);
th=0.1*N_Mfd;
Cum_Sum_Hist_Mfd=cumsum(Hist_Mfd);
ind_th=find(Cum_Sum_Hist_Mfd<=th);
ThR1=Values_Mfd(ind_th(length(ind_th)));  %Threshold dos minimos
% th=0.95*N_Mfd;
% ind_th=find(Cum_Sum_Hist_Mfd>th);
% ThR2=Values_Mfd(ind_th(1));  %Threshold dos minimos
%-------------------------------------------------------------------------%


%-------------------------------------------------------------------------%
%Procura de minimos locais em intervalos alargados------------------------%
Search_Interval=round(Sample_Freq*0.25);  %Fisiologicamente � impossivel haver dois batimentos em menos de 0.3seg
Local_Minimus_Mfd=Local_Min(Mfd,Search_Interval);

Local_Minimus_Mfd(Local_Minimus_Mfd(:,2)>ThR1,:)=[];
N_Local_Minimus_Mfd=size(Local_Minimus_Mfd,1);

Reference_Points=Local_Minimus_Mfd;
N_Reference_Points=N_Local_Minimus_Mfd;
%-------------------------------------------------------------------------%


%-------------------------------------------------------------------------%
%Inicializar variaveis----------------------------------------------------%
Positive_Complex=ones(N_Reference_Points,1);
Search_Interval=round(Search_Interval/2);
%-------------------------------------------------------------------------%
Complex_Indices=zeros(N_Reference_Points,3);
for i=1:N_Reference_Points

    %-------------------------------------------------------------------------%
    %---Verfificar se o pico R � positivo ou negativo-------------------------%
    Interval_B=Reference_Points(i,1)-Search_Interval;if Interval_B<1, Interval_B=1; end
    Interval_A=Reference_Points(i,1)+Search_Interval;if Interval_A>N_Mfd, Interval_A=N_Mfd; end
    Max_PV=max(f(Interval_B:Interval_A,2));%     [Max_PV Max_PX]=max(f(Interval_B:Interval_A,2));
    [Min_PV Min_PX]=min(f(Interval_B:Interval_A,2));Min_PX=Min_PX+Interval_B-1;
    %-------------------------------------------------------------------------%

    %-------------------------------------------------------------------------%
    %---Pico R positivo-------------------------------------------------------%
    if abs(Max_PV)>=abs(Min_PV)/2,

        %-------Detec��o do pico da onda Q----------------------------------------%
        Interval_Bef=Reference_Points(i,1)-Search_Interval; if Interval_Bef<1, Interval_Bef=1; end
        a=Local_Max(Mfd(Interval_Bef:Reference_Points(i,1)),1,Interval_Bef);
        N_a=size(a,1);
        if N_a>1

            Max_Average=mean(a(:,2));
            a=a(a(:,2)>Max_Average*0.7,:);
            %             a=a(find(a(:,2)>Max_Average*0.7),:);
            N_a=size(a,1);
            if N_a>0, 
                Complex_Indices(i,1)=a(end,1); 
            else
                Complex_Indices(i,1:3)=1; continue; 
            end
        elseif N_a==1
            Complex_Indices(i,1)=a(end,1);
        else
            Complex_Indices(i,1:3)=1; continue;
        end

        %-------Detec��o do pico da onda R----------------------------------------%
        Complex_Indices(i,2)=Reference_Points(i,1);

        %-------Detec��o do pico da onda S----------------------------------------%
        Interval_Aft=Reference_Points(i,1)+Search_Interval; if Interval_Aft>N_Mfd, Interval_Aft=N_Mfd; end
        a=Local_Max(Mfd(Reference_Points(i,1):Interval_Aft),1,Reference_Points(i,1));
        N_a=size(a,1);
        if N_a>1

            Max_Average=mean(a(:,2));
            a=a(a(:,2)>Max_Average*0.7,:);
            %             a=a(find(a(:,2)>Max_Average*0.7),:);
            N_a=size(a,1);
            if N_a>0, Complex_Indices(i,3)=a(1,1); else Complex_Indices(i,1:3)=1; continue; end
        elseif N_a==1
            Complex_Indices(i,3)=a(1,1);
        else
            Complex_Indices(i,1:3)=1; continue;
        end

        Positive_Complex(i,1)=1;


        %-------------------------------------------------------------------------%


        %-------------------------------------------------------------------------%
        %---Pico R Negativo-------------------------------------------------------%
    else

        %-------Detec��o do pico da onda R----------------------------------------%
        Reference_Points(i,1)=Min_PX;
        Complex_Indices(i,2)=Reference_Points(i,1);

        %-------Detec��o do pico da onda Q----------------------------------------%
        Interval_Bef=Reference_Points(i,1)-Search_Interval; if Interval_Bef<1, Interval_Bef=1; end
        a=Local_Min(Mfd(Interval_Bef:Reference_Points(i,1)),1,Interval_Bef);
        N_a=size(a,1);
        if N_a>1

            med_min=mean(a(:,2));
            a=a(a(:,2)<med_min*0.7,:);
            %             a=a(find(a(:,2)<med_min*0.7),:);
            N_a=size(a,1);
            if N_a>0, Complex_Indices(i,1)=a(end,1); else Complex_Indices(i,1:3)=1; continue; end
        elseif N_a==1
            Complex_Indices(i,1)=a(end,1);
        else
            Complex_Indices(i,1:3)=1; continue;
        end

        %-------Detec��o do pico da onda S----------------------------------------%
        Interval_Aft=Reference_Points(i,1)+Search_Interval; if Interval_Aft>N_Mfd, Interval_Aft=N_Mfd; end
        a=Local_Min(Mfd(Reference_Points(i,1):Interval_Aft),1,Reference_Points(i,1));
        N_a=size(a,1);
        if N_a>1

            med_min=mean(a(:,2));
            a=a(a(:,2)<med_min*0.7,:);
            %             a=a(find(a(:,2)<med_min*0.7),:);
            N_a=size(a,1);
            if N_a>0, Complex_Indices(i,3)=a(1,1); else Complex_Indices(i,1:3)=1; continue; end
        elseif N_a==1
            Complex_Indices(i,3)=a(1,1);
        else
            Complex_Indices(i,1:3)=1; continue;
        end
        Positive_Complex(i,1)=0;

        %-------------------------------------------------------------------------%

    end

end


%-------------------------------------------------------------------------%
%Excluir ondas R de baixo declive-----------------------------------------%
Amplitude=abs(Mfd(Complex_Indices(:,1))-Mfd(Complex_Indices(:,2)))+abs(Mfd(Complex_Indices(:,3))-Mfd(Complex_Indices(:,2)));
Amplitude_Avrg=mean(Amplitude);
ind_amp=find(Amplitude>Amplitude_Avrg*0.6);
Complex_Indices=Complex_Indices(ind_amp,:);
Positive_Complex=Positive_Complex(ind_amp,:);
%-------------------------------------------------------------------------%


varargout{1}=Complex_Indices;
varargout{2}=Positive_Complex;


