%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%Detec��o das ondas Q, R, S%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%--------------INPUT------------------------------------------------------%
%f0 - janela ECG original
%N_f0 - tamanho da janela
%f - janela ECG j� pr�-processada
%N_f - Tamanho da janela
%Mfd - Derivada morfologica
%N_Mfd - Tamanho da janela da derivada morfologica
%Qon_Soff - Limites do complexo QRS
%Complex_Indices - Indices dos complexos QRS
%Sample_Freq - frequencia de amostragem
%Reading_Window - Janela do ECG
%ECG_Segmentation_root - Caminho da fun��o ECG_Segmentation
%DISPLAY - 0 ou 1 - mostrar grafico ou n�o
%--------------OUTPUT-----------------------------------------------------%
%T_on_off - Indices das ondas T
%Twaves_Selection - Indices das ondas T que obecem ao limiar de correla��o
%-------------------------------------------------------------------------%

function [T_on_off,Twaves_Selection] = Twave_Detection(f,Mfd,...
    N_Mfd,Qon_Soff,Complex_Indices,Sample_Freq,ECG_Segmentation_root)

%-------------------------------------------------------------------------%
%Carregar o modelo da onda T----------------------------------------------%
Twave_Model_root=[ECG_Segmentation_root 'PTWaveModels/'];
load([Twave_Model_root 'Ideal_Twave_Models.mat']);
%-------------------------------------------------------------------------%


%-------------------------------------------------------------------------%
%Inicializa��o de variaveis-----------------------------------------------%
% Q_on=Qon_Soff(:,1);
% N_Q_on=length(Q_on);
S_off=Qon_Soff(:,2);
N_S_off=length(S_off);

Q_peak=Complex_Indices(:,1);
% S_peak=Complex_Indices(:,3);
R_peak=Complex_Indices(:,2);

Wave_Interval=round((Sample_Freq*0.2)/2);
%-------------------------------------------------------------------------%


%-------------------------------------------------------------------------%
%Calculo de limiares positivo e negativo----------------------------------%
Mfd_pos=Mfd(Mfd>=0);
% Mfd_pos=Mfd(find(Mfd>=0));
Th1=mean(Mfd_pos)*0.10;
Mfd_neg=Mfd(Mfd<0);
% Mfd_neg=Mfd(find(Mfd<0));
Th2=mean(Mfd_neg)*0.10;
%-------------------------------------------------------------------------%

%-------------------------------------------------------------------------%
%Calculo dos intervalos QT------------------------------------------------%
RR=diff(R_peak);

%%%%Alterei esta linha%%%%%%%
RR(end+1)=length(f)-R_peak(end);
%%%%Alterei esta linha%%%%%%%
% RR(end+1)=Reading_Window(2)-Reading_Window(1)-R_peak(end);
% RR(end+1)=Reading_Window(2)-R_peak(end);

QT=round((2/9)*RR+0.3*Sample_Freq);  %%Isto pode ser um problema
%-------------------------------------------------------------------------%

Corr_Coef_Twaves=zeros(N_S_off,1);

T_on_off=zeros(N_S_off,3);
for i=1:N_S_off

%     keyboard;
%-------------------------------------------------------------------------%    
%---Calculo do intervalo de procura da onda T-----------------------------%    
    if i==1,
        if N_S_off>1
            Interval_After=Q_peak(i,1)+QT(i);
            if Interval_After>Q_peak(i+1), Interval_After=Q_peak(i+1); end
        else
            Interval_After=Q_peak(i,1)+QT(i);
            if Interval_After>N_Mfd, Interval_After=N_Mfd; end
        end
    elseif i>1 && i<N_S_off,
        int=T_on_off(1:i-1,3)-Q_peak(1:i-1,1);
        int=int(int(:,1)~=0,:);
%         int=int(find(int(:,1)~=0),:);
        N_int=length(int);
        if N_int>0,
            mean_int=round(mean(int));
            if mean_int>QT(i)
                Interval_After=Q_peak(i,1)+round(mean([QT(i) mean_int]));
            else
                Interval_After=Q_peak(i,1)+QT(i);
            end  
        else
            Interval_After=Q_peak(i,1)+QT(i);
        end
        if Interval_After>Q_peak(i+1), Interval_After=Q_peak(i+1); 
        elseif Interval_After<S_off(i,1)-1, Interval_After=S_off(i,1)-1;
        end
    elseif i==N_S_off
        Interval_After=Q_peak(i,1)+QT(i);
        if Interval_After>N_Mfd, Interval_After=N_Mfd; 
        elseif Interval_After<S_off(i,1)-1, Interval_After=S_off(i,1)-1;
        end
    end
        
    Interval_Before=S_off(i,1)-1; % Inicio do intervalo de procura
%-------------------------------------------------------------------------%

%-------------------------------------------------------------------------%
%---Calculo de maximos e minimos locais da derivada-----------------------%
    Sense=round(0.015*Sample_Freq); %sensibilidade de procura dos maxs e mins locais
    b=Mfd(Interval_Before:Interval_After);
    
    Maximums_L1=Local_Max(b,Sense,Interval_Before);
    Maximums_L1=Maximums_L1(Maximums_L1(:,2)>=Th1,:); %maximos locais t�m que ser maiores do que Th1
%     Maximums_L1=Maximums_L1(find(Maximums_L1(:,2)>=Th1),:); %maximos locais t�m que ser maiores do que Th1
%     N_Maximums_L1=size(Maximums_L1,1);
    
    Minimums_L1=Local_Min(b,Sense,Interval_Before);
    Minimums_L1=Minimums_L1(Minimums_L1(:,2)<=Th2,:); %minimos locais t�m que ser menores do que Th2
%     Minimums_L1=Minimums_L1(find(Minimums_L1(:,2)<=Th2),:); %minimos locais t�m que ser menores do que Th2
%     N_Minimums_L1=size(Minimums_L1,1);  
    
    
    Maximums_L2=Local_Max(b,round(Sense*1.5),Interval_Before);
    Maximums_L2=Maximums_L2(Maximums_L2(:,2)>=Th1,:); %maximos locais t�m que ser maiores do que Th1
%     Maximums_L2=Maximums_L2(find(Maximums_L2(:,2)>=Th1),:); %maximos locais t�m que ser maiores do que Th1
    N_Maximums_L2=size(Maximums_L2,1);
    
    Minimums_L2=Local_Min(b,round(Sense*1.5),Interval_Before);
    Minimums_L2=Minimums_L2(Minimums_L2(:,2)<=Th2,:); %minimos locais t�m que ser menores do que Th2
%     Minimums_L2=Minimums_L2(find(Minimums_L2(:,2)<=Th2),:); %minimos locais t�m que ser menores do que Th2
    N_Minimums_L2=size(Minimums_L2,1); 
%-------------------------------------------------------------------------%


%-------------------------------------------------------------------------%
%---Calculo de maximos e minimos locais do sinal f------------------------%
    b=f(Interval_Before:Interval_After);
    Maximums_f=Local_Max(b,Wave_Interval,Interval_Before);
    Maximums_f=Maximums_f(Maximums_f(:,2)>0.02,:);
%     Maximums_f=Maximums_f(find(Maximums_f(:,2)>0.02),:);

    N_Maximums_f=size(Maximums_f,1);

    Minimums_f=Local_Min(b,Wave_Interval,Interval_Before);
    Minimums_f=Minimums_f(Minimums_f(:,2)<-0.02,:);
%     Minimums_f=Minimums_f(find(Minimums_f(:,2)<-0.02),:);
    N_Minimums_f=size(Minimums_f,1);
%-------------------------------------------------------------------------%    



%-------------------------------------------------------------------------%
%---Inicializar variaveis-------------------------------------------------%
    T=[];
%-------------------------------------------------------------------------%

%-------------------------------------------------------------------------%
%---Calcular janelas de selec��o de conjuntos caracteristicos-------------%

%---Positivas-------------------------------------------------------------%
    Maxs_Search_Window=[];
%     N_Maxs_Search_Window=size(Maxs_Search_Window,1);
    if N_Maximums_f>0
        Maxs_Search_Window(:,1)=Maximums_f(:,1)-round(Sample_Freq*0.07);
        Maxs_Search_Window(:,2)=Maximums_f(:,1)+round(Sample_Freq*0.07);
        Maxs_Search_Window=Maxs_Search_Window(Maxs_Search_Window(:,1)>0 & Maxs_Search_Window(:,2)<N_Mfd,:); % Excluir os valores que caem fora do intervalo da Mfd
%         Maxs_Search_Window=Maxs_Search_Window(find(Maxs_Search_Window(:,1)>0 & Maxs_Search_Window(:,2)<N_Mfd),:); % Excluir os valores que caem fora do intervalo da Mfd
    end
    N_Maxs_Search_Window=size(Maxs_Search_Window,1);

%---Negativas-------------------------------------------------------------%
    Mins_Search_Window=[];
    if N_Minimums_f>0
        Mins_Search_Window(:,1)=Minimums_f(:,1)-round(Sample_Freq*0.07);
        Mins_Search_Window(:,2)=Minimums_f(:,1)+round(Sample_Freq*0.07);
        Mins_Search_Window=Mins_Search_Window(Mins_Search_Window(:,1)>0 & Mins_Search_Window(:,2)<N_Mfd,:); % Excluir os valores que caem fora do intervalo da Mfd
%         Mins_Search_Window=Mins_Search_Window(find(Mins_Search_Window(:,1)>0 & Mins_Search_Window(:,2)<N_Mfd),:); % Excluir os valores que caem fora do intervalo da Mfd
    end
    
    N_Mins_Search_Window=size(Mins_Search_Window,1);
%-------------------------------------------------------------------------%



%-------------------------------------------------------------------------%
%---Encontrar conjuntos caracteristicos-----------------------------------%

%---Positivos-------------------------------------------------------------%

    T_pos=zeros(N_Minimums_L2,3);
    for j=1:N_Minimums_L2
        ind_max_antes=find(Maximums_L1(:,1)<Minimums_L2(j,1));
        N_ima=length(ind_max_antes);
        ind_max_depois=find(Maximums_L2(:,1)>Minimums_L2(j,1));
        N_imd=length(ind_max_depois);

        if N_ima==0, T_pos(j,1)=S_off(i,1);
        else T_pos(j,1)=Maximums_L1(ind_max_antes(end),1);
        end

        T_pos(j,2)=Minimums_L2(j,1);

        if N_imd==0, if i<N_S_off, T_pos(j,3)=Interval_After; else T_pos(j,3)=length(Mfd); end
        else T_pos(j,3)=Maximums_L2(ind_max_depois(1),1);
        end

    end
    N_T_pos=size(T_pos,1);
    
%---Negativos-------------------------------------------------------------%   
T_neg=zeros(N_Maximums_L2,3);
    for j=1:N_Maximums_L2
        ind_min_antes=find(Minimums_L1(:,1)<Maximums_L2(j,1));
        N_ima=length(ind_min_antes);
        ind_min_depois=find(Minimums_L1(:,1)>Maximums_L2(j,1));
        N_imd=length(ind_min_depois);

        if N_ima==0, T_neg(j,1)=S_off(i,1);
        else T_neg(j,1)=Minimums_L1(ind_min_antes(end),1); 
        end

        T_neg(j,2)=Maximums_L2(j,1);

        if N_imd==0, if i<N_S_off, T_neg(j,3)=Interval_After; else T_neg(j,3)=length(Mfd); end
        else T_neg(j,3)=Minimums_L1(ind_min_depois(1),1);
        end
    end
    N_T_neg=size(T_neg,1); 
%-------------------------------------------------------------------------%


%-------------------------------------------------------------------------%
%---Selecionar consoante as janelas de selec��o encontradas---------------%

%---Positivas-------------------------------------------------------------%
    if N_T_pos>0
%         ind_sel=[];
        ind_ext=[];
        k=0;
        for j=1:N_Maxs_Search_Window
           ind_sel=find(T_pos(:,2)<Maxs_Search_Window(j,2) & T_pos(:,2)>Maxs_Search_Window(j,1));
           N_is=length(ind_sel);
           if N_is>0, k=k+1;  ind_ext(k:k+N_is-1)=ind_sel; k=k+N_is-1; end
        end
        N_ie=size(ind_ext,1);
        if N_ie>0, T_pos=T_pos(ind_ext,:); else T_pos=[]; end
%         N_T_pos=size(T_pos,1);
    end

    try 
        T_pos=T_pos(f(T_pos(:,2))>0,:);
%         T_pos=T_pos(find(f(T_pos(:,2))>0),:); 
    catch
    end
    
    N_T_pos=size(T_pos,1);


%---Negativas-------------------------------------------------------------%
    if N_T_neg>0
%         ind_sel=[];
        ind_ext=[];
        k=0;
        for j=1:N_Mins_Search_Window
           ind_sel=find(T_neg(:,2)<Mins_Search_Window(j,2) & T_neg(:,2)>Mins_Search_Window(j,1));
           N_is=length(ind_sel);
           if N_is>0, k=k+1;  ind_ext(k:k+N_is-1)=ind_sel; k=k+N_is-1; end
        end
        N_ie=size(ind_ext,1);
        if N_ie>0, T_neg=T_neg(ind_ext,:); else T_neg=[];end
%         N_T_neg=size(T_neg,1);
    end

    try 
        T_neg=T_neg(f(T_neg(:,2))<0,:); 
%         T_neg=T_neg(find(f(T_neg(:,2))<0),:); 
    catch
    end
    N_T_neg=size(T_neg,1);
%-------------------------------------------------------------------------%


%-------------------------------------------------------------------------%
%Juntar conjuntos caracteristicos negativos e positivos e adicionar uma
%etiqueta correspondente(-1 ou 1)-----------------------------------------%
    if N_T_pos>0 && N_T_neg>0,
        T=[T_pos ones(N_T_pos,1)*(1);T_neg ones(N_T_neg,1)*(-1)];
    elseif  N_T_pos>0 && N_T_neg==0,
        T=[T_pos ones(N_T_pos,1)*(1)];
    elseif  N_T_pos==0 && N_T_neg>0,
        T=[T_neg ones(N_T_neg,1)*(-1)];
    end

    N_T=size(T,1);
    if N_T==0,  T_on_off(i,1:3)=Interval_Before+1; continue; end %Se T for vazio passa a frente no ciclo
    T=sortrows(T,2);
%-------------------------------------------------------------------------%

    
    T=T(T(:,1)<T(:,2) & T(:,2)<T(:,3),:); %Excluir linhas em que os valores s�o iguais 2 a 2
%     T=T(find(T(:,1)~=T(:,2) & T(:,2)~=T(:,3)),:); %Excluir linhas em que os valores s�o iguais 2 a 2
    N_T=size(T,1);
    if N_T==0, T_on_off(i,1:3)=Interval_Before+1; continue; end %Se T for vazio passa a frente no ciclo

    
% %-------------------------------------------------------------------------%    
% %---Excluir conjuntos caracteristicos que n�o correspondam aos padroes----%
%     T_length=T(:,3)-T(:,1);
%     ind=find(T_length>0.04*Sample_Freq & T_length<0.72*Sample_Freq);
%     T=T(ind,:);
%     
% %     N_T=size(T,1);
% %     if N_T==0, T_on_off(i,1:3)=Interval_Before+1; continue; end
% %     min_T=min([f0(T(:,1)) f0(T(:,3))]);
% %     T_amplitude=max(f0(T(:,1):T(:,3)))-min_T;
% %     ind=find(T_amplitude<300 & T_amplitude>2);
% %     T=T(ind,:);
%     
%     N_T=size(T,1);
%     if N_T==0, T_on_off(i,1:3)=Interval_Before+1; continue; end
% %-------------------------------------------------------------------------%    
    

%-------------------------------------------------------------------------%
%---Calcular indice de morfologia D---------------------------------------%
    for k=1:N_T
        if T(k,1)~=T(k,3)
            Line=interp1([T(k,1) T(k,3)],[f(T(k,1)) f(T(k,3))],T(k,1):1:T(k,3))';
            Wave_Transf=(f(T(k,1):T(k,3))-Line)*T(k,4);
%             lnt=sqrt((f(T(k,3))-f(T(k,1)))^2+length(T(k,1):1:T(k,3))^2);
%             T(k,5)=((sum(Wave_Transf)/lnt)*max(Wave_Transf));
            T(k,5)=((sum(Wave_Transf)/length(T(k,1):1:T(k,3)))*max(Wave_Transf));
        else
            T(k,5)=0;
        end
    end
%-------------------------------------------------------------------------%    

%-------------------------------------------------------------------------%
%Calcular coeficientes de correlacao das ondas T com uma onda T modelo----%
    for k=1:N_T
            if T(k,4)==1,
                Twave_average=[];
                Twave_average(:,1)=positive_Twave_model;
                N_Twave_average=length(Twave_average);
                [m_Twave_average x_m_Twave_average]=max(Twave_average);
            elseif T(k,4)==-1,
                Twave_average=[];
                Twave_average(:,1)=negative_Twave_model;
                N_Twave_average=length(Twave_average);
                [m_Twave_average x_m_Twave_average]=min(Twave_average);
            end

            Twave=f(T(k,1):T(k,3));
            N_Twave=length(Twave);

            dif_N=N_Twave-N_Twave_average;
            if dif_N<0,
%                 Twave_aux=zeros(abs(dif_N)+N_Twave,1);
%                 Twave_aux(1:abs(dif_N),1)=Twave(1);
%                 Twave_aux(abs(dif_N)+1:end,1)=Twave;
%                 Twave=Twave_aux;
                Twave=[ones(abs(dif_N),1)*Twave(1); Twave];
            else
%                 Twave_average_aux=zeros(abs(dif_N)+N_Twave_average,1);
%                 Twave_average_aux(1:abs(dif_N),1)=Twave_average(1);
%                 Twave_average_aux(abs(dif_N)+1:end,1)=Twave_average;
%                 Twave_average=Twave_average_aux;
                Twave_average=[ones(dif_N,1)*Twave_average(1); Twave_average];
                x_m_Twave_average=x_m_Twave_average+dif_N;
            end
%             N_Twave=length(Twave);
            if T(k,4)==1,
                [m_Twave x_m_T_wave]=max(Twave);
            elseif T(k,4)==-1,
                [m_Twave x_m_T_wave]=min(Twave);
            end
%             N_Twave
            dif_max=x_m_T_wave-x_m_Twave_average;
            if dif_max>0,
%                 Twave_aux=[Twave;ones(dif_max,1)*Twave(end)];
%                 Twave=Twave_aux(dif_max+1:end);


                Twave=[Twave;ones(dif_max,1)*Twave(end)];
                Twave(1:dif_max)=[];
            elseif dif_max<0,
%                 Twave_aux=[ones(abs(dif_max),1)*Twave(1);Twave];
%                 Twave=Twave_aux(1:end+dif_max);            
                
                Twave=[ones(abs(dif_max),1)*Twave(1);Twave];
                Twave(end+dif_max+1:end)=[];
            end
            
            coef_corr_Twave=corrcoef(Twave_average,Twave);
            
            if (isnan(coef_corr_Twave(1,2))==1)
                T(k,6)=0;
            else
                T(k,6)=abs(coef_corr_Twave(1,2));
            end
    end
            
    N_T=size(T,1);
%-------------------------------------------------------------------------%    

%-------------------------------------------------------------------------%
%---Selecionar onda T com base nos coeficientes C e D---------------------%
    T(:,7)=(1:1:N_T)';

    if N_T>=2
        T_par1=sortrows(T,5);
        ind1=T_par1(end-1:end,7);
        T_par2=sortrows(T,6);
        ind2=T_par2(end-1:end,7);
        if ind1(2)==ind2(2),
            T=T(ind1(2),:);            
        else 
            T=T([ind1(2) ind2(2)],:);
            T=sortrows(T,6);
            corr_cmp=T(2,6)-T(1,6);
            if corr_cmp>0.1,
                T=T(2,:);
            else
                T=sortrows(T,2);
                T=T(1,:);
            end
        end
    elseif N_T==0,
        T_on_off(i,1:3)=Interval_Before+1; continue;
    end
    
    Corr_Coef_Twaves(i,1)=T(1,6);
%-------------------------------------------------------------------------%    
       
    T_on_off(i,:)=T(1,1:3);
    clear T T_pos T_neg
    


end


%-------------------------------------------------------------------------%
%Calcular a diferenca entre indices de correlacao-------------------------%
% Twaves_selection=[];
try
    CorrVal_tolerance=0.3;
    maxCorrVal=max(Corr_Coef_Twaves);
    diffMaxTemplate=maxCorrVal-Corr_Coef_Twaves;
    Twaves_Selection=find(diffMaxTemplate<CorrVal_tolerance);
catch
end
%-------------------------------------------------------------------------%

