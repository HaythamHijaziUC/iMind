%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%Detec��o das ondas Q, R, S%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%--------------INPUT------------------------------------------------------%
%f - janela ECG j� pr�-processada
%N_f - Tamanho da janela
%Mfd - Derivada morfologica
%N_Mfd - Tamanho da janela da derivada morfologica
%Sample_Freq - frequencia de amostragem
%Positive_Complex - Boolean que informa se o complexo � positivo ou n�o (1 ou 0)
%DISPLAY - 0 ou 1 - mostrar grafico ou n�o
%--------------OUTPUT-----------------------------------------------------%
%Qon_Soff - Indices das Ondas Q,R,S
%-------------------------------------------------------------------------%



function Qon_Soff = Qon_Soff_Detection(Mfd,N_Mfd,Sample_Freq, ...
    Complex_Indices,Positive_Complex)

%-------------------------------------------------------------------------%
%Inicializa��o de variaveis-----------------------------------------------%
Q_peak=Complex_Indices(:,1);
S_peak=Complex_Indices(:,3);
N_Beats=size(Complex_Indices,1);
Search_Interval=round(Sample_Freq*0.15);
%-------------------------------------------------------------------------%

Q_on=zeros(N_Beats,1);
S_off=zeros(N_Beats,1);

for i=1:N_Beats

    %-------------------------------------------------------------------------%
    %---Pico R positivo-------------------------------------------------------%
    if Positive_Complex(i,1)==1

        %-------Detec��o do inicio da onda Q--------------------------------------%
        Interval_Before=Q_peak(i,1)-Search_Interval;
        if i==1 && Interval_Before<1, Interval_Before=1;
        elseif i>1 && Interval_Before<S_off(i-1), Interval_Before=S_off(i-1,1)+1;
        end

        b=Mfd(Interval_Before:Q_peak(i,1));
        if isempty(b)==0
            if Mfd(S_peak(i,1))<0.7*Mfd(Q_peak(i,1)),
                d=Local_Min(b,round(0.05*Sample_Freq),Interval_Before);
            else
                d=Local_Min(b,1,Interval_Before);
            end
        else
            Q_on(i,1)=Q_peak(i,1);
        end

        d=d(d(:,2)>=0.7*Mfd(Q_peak(i,1)) | d(:,2)<=0.3*Mfd(Q_peak(i,1)),:);
        %         d=d(find(d(:,2)>=0.7*Mfd(Q_peak(i,1)) | d(:,2)<=0.3*Mfd(Q_peak(i,1))),:);
        N_d=size(d,1);
        if N_d~=0, d=d(end,:); else d(1,1)=Q_peak(i,1); end

        Q_on(i,1)=d(:,1);

        %-------Detec��o do fim da onda S-----------------------------------------%
        Interval_After=S_peak(i,1)+Search_Interval;
        if i==N_Beats && Interval_After>N_Mfd, Interval_After=N_Mfd;
        elseif i<N_Beats && Interval_After>Q_peak(i+1), Interval_After=Q_peak(i+1)-1;
        end

        b=Mfd(S_peak(i,1):Interval_After);
        if isempty(b)==0
            if Mfd(Q_peak(i,1))<0.7*Mfd(S_peak(i,1)),
                d=Local_Min(b,round(0.05*Sample_Freq),S_peak(i,1));
            else
                d=Local_Min(b,1,S_peak(i,1));
            end
        else
            S_off(i,1)=S_peak(i,1);
        end

        d=d(d(:,2)>=0.7*Mfd(S_peak(i,1)) | d(:,2)<=0.3*Mfd(S_peak(i,1)),:);
        %         d=d(find(d(:,2)>=0.7*Mfd(S_peak(i,1)) | d(:,2)<=0.3*Mfd(S_peak(i,1))),:);

        N_d=size(d,1);
        if N_d~=0, d=d(1,:); else d(1,1)=S_peak(i,1); end


        S_off(i,1)=d(:,1);
        %-------------------------------------------------------------------------%

        %-------------------------------------------------------------------------%
        %---Pico R negativo-------------------------------------------------------%
    else

        %-------Detec��o do inicio da onda Q--------------------------------------%
        Interval_Before=Q_peak(i,1)-Search_Interval;
        if i==1 && Interval_Before<1, Interval_Before=1;
        elseif i>1 && Interval_Before<S_off(i-1), Interval_Before=S_off(i-1,1)+1;
        end

        b=Mfd(Interval_Before:Q_peak(i,1));
        if isempty(b)==0
            if Mfd(S_peak(i,1))>0.7*Mfd(Q_peak(i,1)),
                d=Local_Max(b,round(0.05*Sample_Freq),Interval_Before);
            else
                d=Local_Max(b,1,Interval_Before);
            end
        else
            Q_on(i,1)=Q_peak(i,1);
        end


        d=d(d(:,2)<=0.7*Mfd(Q_peak(i,1)) | d(:,2)>=0.3*Mfd(Q_peak(i,1)),:);
        %         d=d(find(d(:,2)<=0.7*Mfd(Q_peak(i,1)) | d(:,2)>=0.3*Mfd(Q_peak(i,1))),:);
        N_d=size(d,1);

        if N_d~=0, d=d(end,:); else d(1,1)=Q_peak(i,1); end

        Q_on(i,1)=d(:,1);

        %-------Detec��o do fim da onda S-----------------------------------------%
        Interval_After=S_peak(i,1)+Search_Interval;
        if i==N_Beats && Interval_After>N_Mfd, Interval_After=N_Mfd;
        elseif i<N_Beats && Interval_After>Q_peak(i+1), Interval_After=Q_peak(i+1)-1;
        end
        b=Mfd(S_peak(i,1):Interval_After);
        if isempty(b)==0
            if Mfd(Q_peak(i,1))>0.7*Mfd(S_peak(i,1)),
                d=Local_Max(b,round(0.05*Sample_Freq),S_peak(i,1));
            else
                d=Local_Max(b,1,S_peak(i,1));
            end
        else
            S_off(i,1)=S_peak(i,1);
        end
        d=d(d(:,2)<=0.7*Mfd(S_peak(i,1)) | d(:,2)>=0.3*Mfd(S_peak(i,1)),:);
        %         d=d(find(d(:,2)<=0.7*Mfd(S_peak(i,1)) | d(:,2)>=0.3*Mfd(S_peak(i,1))),:);
        N_d=size(d,1);
        if N_d~=0, d=d(1,:);  else d(1,1)=S_peak(i,1); end



        S_off(i,1)=d(:,1);

        %-------------------------------------------------------------------------%
    end


end


Qon_Soff=[Q_on S_off];

