%??????????????????????????????????????????????? Heart Cycle : ECG Analysis 
%                                      FCTUC - Version 1.0 - September 2008 
%   ??????????????????????????????????????????????????????????????????????? 
%   ECG_Segmentation Segmentation of ecg signal. 
%   Detection of QRS peaks, Q wave onset and S wave offset
%??????????????????????????????????????????????????????????????????????????
%   [Waves_Found, Presignal, Corr_Coef_Pwaves] = ...
%    ECG_Segmentation(Signal, Sample_Freq, Window_Size_Sec, Display)
%??????????????????????????????????????????????????????????????????????????
%   Signal              :ECG signal vector
%   Sample_Freq         :Ecg signal sampling frequency
%   Window_Size_Sec     :Length of the reading window in seconds
%   Display             :0/1 display or not the ecg signal and segmentation
%??????????????????????????????????????????????????????????????????????????
%  WAVES. {structure}   onset, peak and offset of the P, QRS and T waves
%       .P              : Pwave -  [ponset ppeak poffset]
%       .QRS            : QRS complex - [qonset qpeak rpeak speak soffset ]
%       .T              : Twave - [tonset tpeak toffset]
%                       NOTE: Absent waves have index zero;
%   Presignal           :Ecg without noise and baseline drifts,unnormalized
%   Corr_Coef_Pwaves    :Vector indicating the correlation coeficient of
%                        each P wave with an ideal Pwave model

function [Waves_Found_final,preSignal_final,Corr_Coef_Pwaves_final] = ECG_Segmentation(Signal,Sample_Freq,Window_Size_Sec,DISPLAY)

%-------------------------------------------------------------------------%
if nargin<4,
    DISPLAY=0;
    %display('Parameter DISPLAY = 1.');
end
if nargin<3,
    Window_Size_Sec=10;
    %display('Parameter Window_Size_Sec = 10.');
end
if nargin<2,
    Sample_Freq=250;
    %display('Parameter Sample_Freq = 250.');
end
if nargin<1
    %error('ECG Signal not found.');
end
%-------------------------------------------------------------------------%

%-------------------------------------------------------------------------%
ECG_Segmentation_root=mfilename('fullpath');
ECG_Segmentation_root=ECG_Segmentation_root(1:end-length(mfilename));
addpath(genpath(ECG_Segmentation_root));
%-------------------------------------------------------------------------%

N_Samples=length(Signal);

n=0;
i=0;

Waves_Found_final=[];
Corr_Coef_Pwaves_final=[];
preSignal_final = zeros(N_Samples-1,1);


Reading_Window(1)=1;
Reading_Window(2)=Reading_Window(1)+Sample_Freq*Window_Size_Sec-1;

%-------------------------------------------------------------------------%
%disp('');
%disp('..........ECG_SEGMENTATION ..............');
%-------------------------------------------------------------------------%

while (Reading_Window(2)<=N_Samples-1 && n<2)
        try,
    i=i+1;

    disp(['... WINDOW -> ' int2str(i) '...............................' int2str(Reading_Window(1)) ' -> ' int2str(Reading_Window(2)) ' ...']);

    clear ECG;
    ECG(:,1)=Reading_Window(1):Reading_Window(2);
    ECG(:,2)=Signal(Reading_Window(1):Reading_Window(2));

    Waves_Found = zeros(0,11);
    preSignal = [];
    Corr_Coef_Pwaves = [];
% try,
    tic 
    [Waves_Found,preSignal,Corr_Coef_Pwaves] = ECG_Segmentation_Local_Window(ECG,Sample_Freq);
    preSignal_final(Reading_Window(1):Reading_Window(2),1)=preSignal;
    Waves_Found=Waves_Found+Reading_Window(1)-1;
    toc
    last_Reading_Window =Reading_Window;
    Reading_Window(1) = Waves_Found(end,1)-10;
    Reading_Window(2) = Reading_Window(1)+Sample_Freq*Window_Size_Sec-1;

% catch
%     keyboard;
%     Reading_Window(1) = Reading_Window(2)+1;
%     Reading_Window(2) = Reading_Window(1)+Sample_Freq*Window_Size_Sec-1;
%         
% end
    



    if (Reading_Window(2)>N_Samples)
        Reading_Window(2) = N_Samples-1;
        n=n+1;
    end
    
    if Reading_Window(2)<=last_Reading_Window(2) 
        Reading_Window = last_Reading_Window+Sample_Freq*Window_Size_Sec-1;
    end
    Waves_Found(Waves_Found(:,1)==Waves_Found(:,3),1:3)=0;
    Waves_Found(Waves_Found(:,9)==Waves_Found(:,11),9:11)=0;
    Waves_Found(Waves_Found(:,end-2)==Waves_Found(:,end),end:end-2)=0;
% if ~isempty(Waves_Found) && ~isempty(Corr_Coef_Pwaves)
    Waves_Found(end,:)=[];
    Corr_Coef_Pwaves(end,:)=[];
% end

    Waves_Found_final=[Waves_Found_final;Waves_Found];
    Corr_Coef_Pwaves_final = [Corr_Coef_Pwaves_final; Corr_Coef_Pwaves];


    clear ECG Waves_Found preSignal f f_ns Complex_Indices Positive_Complex Pon_off Q_on_off T_on_off Q_on Mfd_QRS Mfd_T Mfd_P

        catch,
            Reading_Window(1) = Reading_Window(2)+1;
            Reading_Window(2) = Reading_Window(1)+Sample_Freq*Window_Size_Sec;
        end

end

%-------------------------------------------------------------------------%
%disp('..........ECG_SEGMENTATION FINISHED..............');
%disp(' ');
%-------------------------------------------------------------------------%

if DISPLAY==45

    close all;

    figure;
    hold on;

    plot(Signal);


    plot(Waves_Found_final(Waves_Found_final(:,1)~=0,1),Signal(Waves_Found_final(Waves_Found_final(:,1)~=0,1)),'^r');
    plot(Waves_Found_final(Waves_Found_final(:,2)~=0,2),Signal(Waves_Found_final(Waves_Found_final(:,2)~=0,2)),'.r');
    plot(Waves_Found_final(Waves_Found_final(:,3)~=0,3),Signal(Waves_Found_final(Waves_Found_final(:,3)~=0,3)),'^r');

    plot(Waves_Found_final(:,4),Signal(Waves_Found_final(:,4)),'vy');
    plot(Waves_Found_final(:,5),Signal(Waves_Found_final(:,5)),'.y');
    plot(Waves_Found_final(:,6),Signal(Waves_Found_final(:,6)),'.k');
    plot(Waves_Found_final(:,7),Signal(Waves_Found_final(:,7)),'.c');
    plot(Waves_Found_final(:,8),Signal(Waves_Found_final(:,8)),'vc');

    plot(Waves_Found_final(Waves_Found_final(:,9)~=0,9),Signal(Waves_Found_final(Waves_Found_final(:,9)~=0,9)),'^g');
    plot(Waves_Found_final(Waves_Found_final(:,10)~=0,10),Signal(Waves_Found_final(Waves_Found_final(:,10)~=0,10)),'.g');
    plot(Waves_Found_final(Waves_Found_final(:,11)~=0,11),Signal(Waves_Found_final(Waves_Found_final(:,11)~=0,11)),'^g');

end


