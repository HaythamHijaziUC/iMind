%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%Fun��o para elimina��o do ru�do do ECG%%%%%%%%%%%%%%%%%%%%% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%--------------INPUT------------------------------------------------------%
%Signal - janela ECG e indices
%N_Signal - Tamanho da janela
%--------------OUTPUT-----------------------------------------------------%
%f_ns - janela ECG sem ruido
%N_f_ns - Tamanho da janela
%Signal - janela ECG e indices
%N_Signal - Tamanho da janela
%-------------------------------------------------------------------------%

function varargout = Noise_Supression(Signal)


B1=[0;1;5;1;0];
B2=[0;0;0;0;0];
% N_B1=length(B1);
% N_B2=length(B2);

f1=Dilatation(Signal(:,2),B1);
f1=Erosion(f1,B2);
f2=Erosion(Signal(:,2),B1);
f2=Dilatation(f2,B2);

f_ns(:,2)=f1+f2;
N_f_ns=length(f_ns);
f_ns(:,1)=Signal(:,1);

varargout{1} = f_ns;
varargout{2} = N_f_ns;
varargout{3} = Signal;




