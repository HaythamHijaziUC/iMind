%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%Fun��o para detectar maximos locais%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%--------------INPUT------------------------------------------------------%
%Signal - Sinal
%Scale - Sensibilidade de detec��o
%Input_Indice - 1� indice da janela global do sinal
%Output_Max - Indice do maximo a calcular (1�, 2�, ..., todos (0))
%--------------OUTPUT-----------------------------------------------------%
%Local_Maximums - Maximos locais (indices e valores)
%-------------------------------------------------------------------------%

function Local_Maximums = Local_Max(Signal,Scale,Input_Indice,Output_Max)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if nargin<4
    Output_Max=0;
end
if nargin<3
    Input_Indice=1;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Local_Maximums=[];

k = 2*Scale+1;
y = zeros(k,1);

Signal=cat(1,ones(Scale,1)*Signal(1,1),Signal,ones(Scale,1)*Signal(length(Signal),1));
N = length(Signal);

l = 0;
for j=Scale+1:N-Scale
   y = Signal(j-Scale:j+Scale);
   [ymax,imax] = max(y);
   if imax == Scale+1
      l = l+1;
      Local_Maximums(l,2) = ymax;
      Local_Maximums(l,1) = j+Input_Indice-Scale-1; if Local_Maximums(l,1)<1, Local_Maximums(l,1)=1; end
   end
end

N_maxim_l=size(Local_Maximums,1);
if N_maxim_l>0
    if Output_Max>0 
        if Output_Max>N_maxim_l, Output_Max=N_maxim_l; end
        Local_Maximums=[Local_Maximums(Output_Max,1) Local_Maximums(Output_Max,2)];
    elseif Output_Max<0
        posicao_out=N_maxim_l+Output_Max;
        if posicao_out<1, posicao_out=0; end
        Local_Maximums=[Local_Maximums(posicao_out+1,1) Local_Maximums(posicao_out+1,2)];
    end
elseif N_maxim_l==0
    if Output_Max<0
        Local_Maximums(1,2) = Signal(N-Scale);
        Local_Maximums(1,1) = N-2*Scale+Input_Indice-1;
    else    
        Local_Maximums(1,2) = Signal(Scale+1);
        Local_Maximums(1,1) = Input_Indice;
    end
end
