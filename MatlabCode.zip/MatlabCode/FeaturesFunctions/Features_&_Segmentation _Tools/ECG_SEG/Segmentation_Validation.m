close all;
clear all;
clc;

%->Caminho para os ficheiros com info do algoritmo de segmentacao
Waves_root=mfilename('fullpath');
Waves_root=[Waves_root(1:end-length(mfilename)-length('ECG_Analysis_offline\Characteristic_Wave_Search\Validation\')) 'ECG_Feature_Extractor_offline\Waves\QT\' ];
% Waves_root='\\10.3.1.209\matlab7\work\LifeStream\ECG_Feature_Extractor\Waves\';

%->Caminho para a lista de ficheiros
Files_List_root=mfilename('fullpath');
Files_List_root=[Files_List_root(1:end-length(mfilename)-length('Characteristic_Wave_Search\Validation\')) 'DB_Readers\Data\DB_List\'];


%->Caminho para os DB_Files
DB_Files_root=mfilename('fullpath');
DB_Files_root=[DB_Files_root(1:end-length(mfilename)-length('ECG_Analysis_offline\Characteristic_Wave_Search\Validation\')) 'ECG_DB_Info_Extractor\DB_Files\QT_DB\']

%->Load da lista de ficheiros
Database='QT_DB';
load([Files_List_root Database '_List.mat']);
eval(['LIST=LIST_' Database(1,1:end-3) ';']);
N_LIST=length(LIST);


for i=83:N_LIST
    
    
    display(['READING FILE ' LIST{i,1} '...']);
    
    %->Load dos ficheiros de waves
    load([ Waves_root 'Waves_' LIST{i,1} '.mat']);

    
    %->Load dos ficheiros DB_File
    load([ DB_Files_root 'DB_File_' LIST{i,1} '.mat']);
    
    Reading_Ch=Choose_Channel(LIST{i,1},Database);

    P_on_off_real=DB_File.Annotations{Reading_Ch+3,1}.Pwaves; P_on_off_real([1 end],:)=[];
    N_P_waves_real=size(P_on_off_real,1); 
    QRS_complex_real=[DB_File.Annotations{Reading_Ch+3,1}.Qwaves ...
        DB_File.Annotations{Reading_Ch+3,1}.Rwaves DB_File.Annotations{Reading_Ch+3,1}.Swaves]; QRS_complex_real([1 end],:)=[];
    N_QRS_complex_real=size(QRS_complex_real,1);
    T_on_off_real=DB_File.Annotations{Reading_Ch+3,1}.Twaves;T_on_off_real([1 end],:)=[];
    N_T_waves_real=size(T_on_off_real,1);

    P_on_off_found=Signal_Data.Waves_Found(:,1:3);
    P_on_off_found(find(P_on_off_found(:,1)==0),:)=[];
    N_P_waves_found=size(P_on_off_found,1);
    QRS_complex_found=Signal_Data.Waves_Found(:,4:8);
    N_QRS_complex_found=size(QRS_complex_found,1);
    T_on_off_found=Signal_Data.Waves_Found(:,9:11);
    T_on_off_found(find(T_on_off_found(:,1)==0),:)=[];
    N_T_waves_found=size(T_on_off_found,1);
    


    j=0;
    True_positives=0;
    for l=1:N_P_waves_real
        indice=find((P_on_off_found(:,1)>=P_on_off_real(l,1) & P_on_off_found(:,1)<=P_on_off_real(l,3))...
            | (P_on_off_found(:,2)>=P_on_off_real(l,1) & P_on_off_found(:,2)<=P_on_off_real(l,3))...
            | (P_on_off_found(:,3)>=P_on_off_real(l,1) & P_on_off_found(:,3)<=P_on_off_real(l,3)));
        if length(indice)~=0,
            j=j+1;
            P_erro(j,1)=abs(P_on_off_real(l,1)-P_on_off_found(indice(1),1));
            P_erro(j,2)=abs(P_on_off_real(l,2)-P_on_off_found(indice(1),2));
            P_erro(j,3)=abs(P_on_off_real(l,3)-P_on_off_found(indice(end),3));
            True_positives=True_positives+1;
        end
    end

    False_negatives=N_P_waves_real-True_positives;
    False_positives=N_P_waves_found-True_positives;

    P_waves.True_positives=True_positives;
    P_waves.False_negatives=False_negatives;
    P_waves.False_positives=False_positives;

    if True_positives==0 && N_P_waves_real==0
        sensibility.P_waves=1;
        pos_predictivity.P_waves=1;
    else
        sensibility.P_waves=True_positives/(True_positives+False_negatives);
        pos_predictivity.P_waves=True_positives/(True_positives+False_positives);
    end


    %--------------------------------------------------------------------------

    %--------------------------------------------------------------------------
    j=0;
    True_positives=0;
    for l=1:N_QRS_complex_real
        indice=find((QRS_complex_found(:,1)>QRS_complex_real(l,1) & QRS_complex_found(:,1)<QRS_complex_real(l,3))...
        | (QRS_complex_found(:,3)>QRS_complex_real(l,1) & QRS_complex_found(:,3)<QRS_complex_real(l,3))...
        | (QRS_complex_found(:,5)>QRS_complex_real(l,1) & QRS_complex_found(:,5)<QRS_complex_real(l,3)));
        if length(indice)~=0,
            j=j+1;
            QRS_erro(j,1)=abs(QRS_complex_real(l,1)-QRS_complex_found(indice(1),2));
            QRS_erro(j,2)=abs(QRS_complex_real(l,2)-QRS_complex_found(indice(1),3));
            QRS_erro(j,3)=abs(QRS_complex_real(l,3)-QRS_complex_found(indice(end),4));
            True_positives=True_positives+1;
        end
    end

    False_negatives=N_QRS_complex_real-True_positives;
    False_positives=N_QRS_complex_found-True_positives;

    QRS_complexes.True_positives=True_positives;
    QRS_complexes.False_negatives=False_negatives;
    QRS_complexes.False_positives=False_positives;

    if True_positives==0 && N_QRS_complex_real==0
        sensibility.QRS_complexes=1;
        pos_predictivity.QRS_complexes=1;
    else
        sensibility.QRS_complexes=True_positives/(True_positives+False_negatives);
        pos_predictivity.QRS_complexes=True_positives/(True_positives+False_positives);
    end

    %--------------------------------------------------------------------------

    %--------------------------------------------------------------------------
    j=0;
    True_positives=0;
    for l=1:N_T_waves_real
        indice=find((T_on_off_found(:,1)>T_on_off_real(l,1) & T_on_off_found(:,1)<T_on_off_real(l,3))...
        | (T_on_off_found(:,2)>T_on_off_real(l,1) & T_on_off_found(:,2)<T_on_off_real(l,3))...
        | (T_on_off_found(:,3)>T_on_off_real(l,1) & T_on_off_found(:,3)<T_on_off_real(l,3)));
        if length(indice)~=0,
            j=j+1;
            T_erro(j,1)=abs(T_on_off_real(l,1)-T_on_off_found(indice(1),1));
            T_erro(j,2)=abs(T_on_off_real(l,2)-T_on_off_found(indice(1),2));
            T_erro(j,3)=abs(T_on_off_real(l,3)-T_on_off_found(indice(end),3));
            True_positives=True_positives+1;
        end
    end

    False_negatives=N_T_waves_real-True_positives;
    False_positives=N_T_waves_found-True_positives;

    T_waves.True_positives=True_positives;
    T_waves.False_negatives=False_negatives;
    T_waves.False_positives=False_positives;

    if True_positives==0 && N_T_waves_real==0
        sensibility.T_waves=1;
        pos_predictivity.T_waves=1;
    else
        sensibility.T_waves=True_positives/(True_positives+False_negatives);
        pos_predictivity.T_waves=True_positives/(True_positives+False_positives);
    end

    %--------------------------------------------------------------------------
    mean_error.P_waves(1)=mean(P_erro(:,1));
    mean_error.P_waves(2)=mean(P_erro(:,2));
    mean_error.P_waves(3)=mean(P_erro(:,3));

    mean_error.QRS_complexes(1)=mean(QRS_erro(:,1));
    mean_error.QRS_complexes(2)=mean(QRS_erro(:,2));
    mean_error.QRS_complexes(3)=mean(QRS_erro(:,3));

    mean_error.T_waves(1)=mean(T_erro(:,1));
    mean_error.T_waves(2)=mean(T_erro(:,2));
    mean_error.T_waves(3)=mean(T_erro(:,3));

    error.P_waves(1)=sum(P_erro(:,1));
    error.P_waves(2)=sum(P_erro(:,2));
    error.P_waves(3)=sum(P_erro(:,3));

    error.QRS_complexes(1)=sum(QRS_erro(:,1));
    error.QRS_complexes(2)=sum(QRS_erro(:,2));
    error.QRS_complexes(3)=sum(QRS_erro(:,3));

    error.T_waves(1)=sum(T_erro(:,1));
    error.T_waves(2)=sum(T_erro(:,2));
    error.T_waves(3)=sum(T_erro(:,3));


    Wave_valid.sensibility=sensibility;
    Wave_valid.pos_predictivity=pos_predictivity;
    Wave_valid.P_waves=P_waves;
    Wave_valid.QRS_complexes=QRS_complexes;
    Wave_valid.T_waves=T_waves;
    Wave_valid.mean_error=mean_error;
    Wave_valid.error=error;

%         display(['%-------------Segmentation Window Statistics---------------------------%\n']);
%         disp('Sensibility:');
%         disp(Wave_valid.sensibility(:));
%         disp('');
%         disp('Positive Predictivity:');
%         disp(Wave_valid.pos_predictivity(:));
%         disp('');
%         disp('----Mean error P wave:');
%         disp('    onset     peak      offset');
%         disp(Wave_valid.mean_error.P_waves(:)');
%         disp('');
%         disp('----Mean error QRS complex:');
%         disp('    onset     peak      offset');
%         disp(Wave_valid.mean_error.QRS_complexes(:)');
%         disp('');
%         disp('----Mean error T wave:');
%         disp('    onset     peak      offset');
%         disp(Wave_valid.mean_error.T_waves(:)');
%         display(['%----------------------------------------------------------------------%']);


    Sensibilidade_P(i,1)=Wave_valid.sensibility.P_waves;
    Sensibilidade_R(i,1)=Wave_valid.sensibility.QRS_complexes;
    Sensibilidade_T(i,1)=Wave_valid.sensibility.T_waves;

    Pos_Pred_P(i,1)=Wave_valid.pos_predictivity.P_waves;
    Pos_Pred_R(i,1)=Wave_valid.pos_predictivity.QRS_complexes;
    Pos_Pred_T(i,1)=Wave_valid.pos_predictivity.T_waves;

    Estatistica_P(i,1)=Wave_valid.sensibility.P_waves;
    Estatistica_P(i,2)=Wave_valid.pos_predictivity.P_waves;
    Estatistica_P(i,3:5)=mean_error.P_waves(1:3);
    Estatistica_QRS(i,1)=Wave_valid.sensibility.QRS_complexes;
    Estatistica_QRS(i,2)=Wave_valid.pos_predictivity.QRS_complexes;
    Estatistica_QRS(i,3:5)=mean_error.QRS_complexes(1:3);
    Estatistica_T(i,1)=Wave_valid.sensibility.T_waves;
    Estatistica_T(i,2)=Wave_valid.pos_predictivity.T_waves;
    Estatistica_T(i,3:5)=mean_error.T_waves(1:3);

    eval(['Wave_validation_' LIST{i,1} '=Wave_valid;']);
    clear Wave_valid;

end





