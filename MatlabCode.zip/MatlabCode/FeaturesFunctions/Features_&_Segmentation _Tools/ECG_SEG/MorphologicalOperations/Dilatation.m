%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%Fun��o para realizar a opera��o de dilata��o%%%%%%%%%%%%%%% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%--------------INPUT------------------------------------------------------%
%f1 - fun��o 1
%f2 - fun��o 2
%--------------OUTPUT-----------------------------------------------------%
%f - fun��o resultante
%-------------------------------------------------------------------------%

function f=Dilatation(f1,f2)

% N_fun1=length(f1);
N_fun2=length(f2);
jan1=round((N_fun2-1)/2);
jan2=round((N_fun2+1)/2);
f1=[ones(jan1,1)*f1(1);f1;ones(jan2,1)*f1(end)];
N_fun1=length(f1);
janela=1:1:N_fun2;
f=zeros(N_fun1-jan2-jan1,1);
for i=jan1+1:N_fun1-jan2
    val=janela+i-jan1-1;
    f(i-jan1,1)=max(f1(val,1)+f2(janela,1));
end

