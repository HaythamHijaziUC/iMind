%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%Fun��o para eliminar as flutua��es da linha de base do ECG%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%--------------INPUT------------------------------------------------------%
%Signal - janela ECG e indices
%N_Signal - Tamanho da janela
%Sample_Freq - Frequencia de amostragem
%Bo - Fun��o estruturante
%--------------OUTPUT-----------------------------------------------------%
%f - janela ECG sem flutua��es da linha de base
%N_f4 - Tamanho da janela
%Signal - janela ECG e indices
%N_Signal - Tamanho da janela
%-------------------------------------------------------------------------%

function varargout = Base_Line_Drift_Supression(Signal,N_Signal,Bo)

% Bo=zeros(round(0.2*Sample_Freq),1);
N_Bo=length(Bo);
parm=round(1.5*N_Bo);if parm/2==round(parm/2),parm=parm+1; end
Bc=zeros(parm,1);
% N_Bc=length(Bc);

f1=Erosion(Signal(:,2),Bo);
f2=Dilatation(f1,Bo);
f3=Dilatation(f2,Bc);
f4=Erosion(f3,Bc);

N_f4=length(f4);

f(:,1)=Signal(:,1);
f(:,2)=Signal(:,2)-f4;

varargout{1} = f;
varargout{2} = N_f4;
varargout{3} = Signal;
varargout{4} = N_Signal;


