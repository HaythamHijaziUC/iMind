%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%Calculo da derivada morfologica%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%--------------INPUT------------------------------------------------------%
%Signal - janela ECG e indices
%N_Signal - Tamanho da janela
%Scale - Escala utilizada no calculo
%--------------OUTPUT-----------------------------------------------------%
%f - janela ECG sem flutua��es da linha de base
%Mfd - derivada morfologica do sinal do sinal
%-------------------------------------------------------------------------%

function Mfd = Morphological_Derivative(Signal,N_Signal,Scale)

Gs=zeros(Scale*2+1,1);

f1=Dilatation(Signal,Gs);
f2=Erosion(Signal,Gs);

N_f2=length(f2);

Mfd=zeros(N_f2,1);
for i=1:N_f2
   Mfd(i,1)=(f1(i)+f2(i)-2*Signal(i))/Scale ;
end

Mfd=Mfd/(max(Mfd)-min(Mfd));
