function [ApEn_value,Cmr,Cmr_1] = fast_ApEn(signal,r_factor)
% fast_ApEn
% Estimate the Aproximate Entropy (ApEn) of a signal, using a fast
% algorithm, for the ApEn parameter "m" equal to 2 (appropriate for a HRV
% signal).
% The pattern length "m" for which this routine was implemented is 2. For
% another values of "m", the instructions marked with a (*) in the end must be changed.
% Reference: Nonlinear Biomedical Signal Processing (pp 76-78)
% Metin Akay
% Reference values for the parameters: (Pincus, 1995, Chaos) (Pincus, 2000)
% m=1 or m=2
% r between 0.1*SD and 0.25*SD, where SD is the signal standard deviation
% N (signal length) between 75 and 5000;
% [ApEn_value] = fast_ApEn(signal,r_factor);
% Input variables:
% signal - signal
% r_factor - factor of the criterion of similarity r_factor*std(signal)
% Output variables:
% ApEn_value - ApEn calculated from the signal
% Optional output variables:
% C_m
% C_m_1
% Hern�ni Gon�alves. 29.June.2004
% Last update:
% MATLAB Release 13
% Input variables validation.
if nargin<2
    r_factor=0.2;
end
%.... remove comment
% if length(signal)<75 | length(signal)>5000
%     ecgWarning('   Fast Entropy Funcion ');
%     slength=input('Signal length inappropriate. Continue anyway? (y/n)','s');
%     if strcmpi(slength,'y')==0 
%         return
%     end
% end
if r_factor<0.1 | r_factor>0.25
    r_factor_flag=input('Value for ''r'' parameter is inappropriate. Continue anyway? (y/n)','s');
    if strcmpi(r_factor_flag,'y')==0
        return
    end
end
% Initial variables definition.
signal=signal(:);
N=length(signal);
Cmr_ij=[];Cmr_i=[];Cmr=[];
Cmr_ij_1=[];Cmr_i_1=[];Cmr_1=[];
% D and S matrixes computation.
D=abs(signal*ones(1,N)-ones(N,1)*signal');
S=zeros(N,N);
S(find(D<=r_factor*std(signal)))=1;
% C�s computation for "m" and "m+1" patterns.
m=2;
S(N+1,(m+1):N)=0; % necessary for the loop to be possible ("artificial" definitions)
for k=1:N-(m-1)
    % m pattern.
    Cmr_ij=S(k,1:N-1).*S(k+1,2:N); % (*)
    Nm_i=sum(Cmr_ij);
    Cmr_i=Nm_i/(N-(m-1));
    Cmr=[Cmr; Cmr_i];
    % m+1 pattern.
    Cmr_ij(end)=[];
    Cmr_ij_1=Cmr_ij.*S(k+2,3:N);
    Nm_i_1=sum(Cmr_ij_1);
    Cmr_i_1=Nm_i_1/(N-m);
    Cmr_1=[Cmr_1;Cmr_i_1];
end
Cmr_1(end)=[]; % the last C value for the "m+1" pattern is artificial.
% Phi�s computation.
phi_m=mean(log(Cmr));
phi_m_1=mean(log(Cmr_1));
% ApEn final calculation.
ApEn_value=[phi_m-phi_m_1];