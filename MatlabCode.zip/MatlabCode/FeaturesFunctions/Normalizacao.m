function [SinalNormalizado] = Normalizacao(sinal)
SinalNormalizado = sinal/max(abs(sinal));
return
end

