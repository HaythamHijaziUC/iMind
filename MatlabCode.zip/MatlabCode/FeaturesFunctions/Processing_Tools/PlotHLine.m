function PlotHLine(indexes,color,line_style,line_width)

indexes = indexes(:)';

switch nargin
    case 4
        line([ones(length(indexes),1)*xlim]',[indexes; indexes],'Color',color,'LineStyle',line_style,'Linewidth',line_width);
    case 3
        line([ones(length(indexes),1)*xlim]',[indexes; indexes],'Color',color,'LineStyle',line_style);
    case 2
        line([ones(length(indexes),1)*xlim]',[indexes; indexes],'Color',color);
    otherwise
        warning('Not enought input arguments')
        return;
end


