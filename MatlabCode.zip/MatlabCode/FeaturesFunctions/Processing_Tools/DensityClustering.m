function [groups, idx, corepts] = DensityClustering(new_time, new_left_posx_data, new_left_posy_data, new_samples_code, code_line_heigh, code_line_gap, new_fs)


kD = pdist2([new_left_posx_data(new_samples_code)],...
    [new_left_posx_data(new_samples_code)]);
dist = diag(kD,1);
dist = [0;dist];
dist = (dist);


minpts = new_fs*2;
codel_oi = 2;
epsilon = codel_oi*code_line_heigh+(codel_oi-1)*5;
line_code_height = code_line_heigh + code_line_gap;

[idx,corepts] = dbscan([new_time(new_samples_code), new_left_posy_data(new_samples_code),dist],epsilon,minpts,'Distance','seuclidean','Scale',[(1/new_fs) 0.5 1]);

groups = sort(unique(idx));