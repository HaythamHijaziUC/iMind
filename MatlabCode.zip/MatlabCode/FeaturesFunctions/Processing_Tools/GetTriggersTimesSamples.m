function [triggers] = GetTriggersTimesSamples(time,states_time_boundaries,offset_start,offset_end)

    %% Get the boundaries of the states ids
    
    fixation_cross_ids = 1;
    text_read_ids = [2 21];
    neutral_code_ids = [22 41];
    code_ids = [42 61];
    
    %% Set time offsets

    
    %% Get text times
    ref_ids = text_read_ids;
    trigger_text_start = states_time_boundaries(find(states_time_boundaries(:,1)>=ref_ids(1) & ...
        states_time_boundaries(:,1)<=ref_ids(2),1,'first'),2);
    trigger_text_end = states_time_boundaries(find(states_time_boundaries(:,1)>=ref_ids(1) & ...
        states_time_boundaries(:,1)<=ref_ids(2),1,'last'),3);

    triggers.text.samples = find(time>=trigger_text_start+offset_start & time<=trigger_text_end-offset_end);
    triggers.text.time = time(triggers.text.samples);
    
    %% Get neutral times
    ref_ids = neutral_code_ids;
    trigger_neutral_start = states_time_boundaries(find(states_time_boundaries(:,1)>=ref_ids(1) & ...
        states_time_boundaries(:,1)<=ref_ids(2),1,'first'),2);
    trigger_neutral_end = states_time_boundaries(find(states_time_boundaries(:,1)>=ref_ids(1) & ...
        states_time_boundaries(:,1)<=ref_ids(2),1,'last'),3);

    triggers.neutral.samples = find(time>=trigger_neutral_start+offset_start & time<=trigger_neutral_end-offset_end);
    triggers.neutral.time = time(triggers.neutral.samples);

    %% Get codes times
    ref_ids = code_ids;
    trigger_code_start = states_time_boundaries(find(states_time_boundaries(:,1)>=ref_ids(1) & ...
        states_time_boundaries(:,1)<=ref_ids(2),1,'first'),2);
    trigger_code_end = states_time_boundaries(find(states_time_boundaries(:,1)>=ref_ids(1) & ...
        states_time_boundaries(:,1)<=ref_ids(2),1,'last'),3);

    triggers.code.samples = find(time>=trigger_code_start+offset_start & time<=trigger_code_end-offset_end);
    triggers.code.time = time(triggers.code.samples);
    
    %% Get crosses times
    trigger_cross_start = [];
    trigger_cross_end = [];
    triggers.crosses.samples = {};
    triggers.crosses.time = {};
    
    ref_ids = fixation_cross_ids;
    ind_crosses = find(states_time_boundaries(:,1)==ref_ids(1));
    for ci=1:length(ind_crosses)
        trigger_cross_start(ci,1) = states_time_boundaries(ind_crosses(ci),2);
        trigger_cross_end(ci,1) = states_time_boundaries(ind_crosses(ci),3);
        triggers.crosses.samples{ci,1} = find(time>=trigger_cross_start(ci,1)+offset_start & time<=trigger_cross_end(ci,1)-offset_end);
        triggers.crosses.time{ci,1} = time(triggers.crosses.samples{ci,1});

    end
    
    