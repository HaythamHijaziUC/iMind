function [fN_y, window,pts_x,pts_y,Y,N_y] = GetHistogramFromData(new_left_posx_data, new_left_posy_data,new_samples_code,line_code_height, image_height,image_width)


grid_size_y = round(image_height/(line_code_height/2));
grid_size_x = round((image_width/10)/10);
pts_x = linspace(0, image_width, grid_size_x);
pts_y = linspace(0, image_height, grid_size_y);

[N,Xedges,Yedges] = histcounts2(new_left_posx_data(new_samples_code),new_left_posy_data(new_samples_code), pts_x, pts_y);
N_y = sum(N,1);
[X,Y] = meshgrid(pts_x(1:end-1)+mean(diff(pts_x))/2,pts_y(1:end-1)+mean(diff(pts_y))/2);
Y = Y(:,1);
X = X(1,:);
window_n=5;
window = ones(1, window_n)/window_n;
fN_y = N_y;%filter(window, 1, N_y);
