function PlotVLine(indexes,color,line_style,marker)

indexes = indexes(:)';
if nargin<4,
    line([indexes; indexes],[ones(length(indexes),1)*ylim]','Color',color,'LineStyle',line_style);
else
    line([indexes; indexes],[ones(length(indexes),1)*ylim]','Color',color,'LineStyle',line_style,'Marker',marker);
end

