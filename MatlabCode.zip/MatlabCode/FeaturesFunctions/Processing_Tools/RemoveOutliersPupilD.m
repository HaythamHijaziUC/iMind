function [ind_in,ind_out] = RemoveOutliersPupilD(data,p,display)

if nargin<3
  display =1;
end
if nargin<2
    p=1.5;  %------------- 80%
end
if nargin<1
    ecgWarning('Error: input should be a data vector','RemoveOutlier');
    ind_in=[];
    ind_out = [];
    return;
end
    
data = [data(1);data];
ddata = diff(data);

N=length(ddata);
sdata=sort(ddata);
iJ1=fix(0.25*N);
iJ2=fix(0.50*N);
iJ3=fix(0.75*N);
J1=sdata(iJ1);
J2=sdata(iJ2);
J3=sdata(iJ3);

ind0 = [];
indn0 = 1:length(ddata);


if J1==J3
ind0 = find (ddata==J1);
indn0 = find(ddata~=J1);    
ddata = ddata(indn0);

N=length(ddata);
sdata=sort(ddata);
iJ1=fix(0.25*N);
iJ2=fix(0.50*N);
iJ3=fix(0.75*N);
J1=sdata(iJ1);
J2=sdata(iJ2);
J3=sdata(iJ3);  

end

dJ=J3-J1;
limInf=J1-p*dJ;
limSup=J3+p*dJ;
ind_out = [];
ind_in=[];
for i=1:N
    if ddata(i)>=limSup
        ind_out=[ind_out; i];
    elseif ddata(i)<=limInf
        ind_out=[ind_out; i];
    else
        ind_in=[ind_in; i];
    end
end

ind_in_d = ind_in;
ind_out_d = ind_out;

ind_in = indn0(ind_in_d);
ind_out = indn0(ind_out_d);


if display ==1,
figure
hold on
ax(1) = subplot(2,1,1)
hold on
plot(indn0,ddata,'b')
plot(ind_in,ddata(ind_in_d),'.r')
plot(ind_out,ddata(ind_out_d),'ok')
ax(2) = subplot(2,1,2)
hold on
plot(data,'b')
plot(ind_in,data(ind_in),'.r')
plot(ind_out,data(ind_out),'ok')
linkaxes(ax,'x')
end
