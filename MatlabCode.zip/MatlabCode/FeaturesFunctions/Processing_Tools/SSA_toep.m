function [RC,PC,C,LAMBDA,RHO] = SSA_toep(cY,M,N,cmp_vec)

covX = xcorr(cY,M-1,'unbiased');
Ctoep=toeplitz(covX(M:end));

Y=zeros(N-M+1,M);
for m=1:M
  Y(:,m) = cY((1:N-M+1)+m-1);
end;

C=Ctoep;

[RHO,LAMBDA] = eig(C);
LAMBDA = diag(LAMBDA);               % extract the diagonal elements
[LAMBDA,ind]=sort(LAMBDA,'descend'); % sort eigenvalues
RHO = RHO(:,ind);                    % and eigenvectors

PC = Y*RHO;

RC=zeros(N,length(cmp_vec));
o=0;
for m=cmp_vec
    o=o+1;
  buf=PC(:,m)*RHO(:,m)'; % invert projection
  buf=buf(end:-1:1,:);
  for n=1:N % anti-diagonal averaging
    RC(n,o)=mean( diag(buf,-(N-M+1)+n) );
  end
end;
end
