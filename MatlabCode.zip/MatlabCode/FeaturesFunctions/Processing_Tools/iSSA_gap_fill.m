function [new_x] = iSSA_gap_fill(x,gaps_indexes,M,theta,rho,display)

if nargin<6,
    display = 0;
end
if nargin<5,
    theta = 0.05;
end
if nargin<4,
    rho= 1;
end
if nargin<3,
    M = 150;
end
if nargin<2,
    warning('No gaps to fill provided')
    return;
    new_x = [];
end
if nargin<1,
    warning('Not enough inputs!!')
    return;
    new_x = [];
end

%%
x_ap = x;
N=length(x_ap);
cmp_vec = 1;

conf_vector = ones(N,1);
conf_vector(gaps_indexes)=0;

no_gaps_indexes = find(conf_vector==1);

%% Initialization (calculate RC1 and subtract to x; substract mean to x)
% [RC,PC,C,LAMBDA,RHO] = SSA_toep(x_ap,M,N,1);
% RC0 = RC;
% x_ap0 = x_ap(:)-RC0(:);
% x_ap_mean0 = mean(x_ap0);
% x_ap0 = x_ap0-x_ap_mean0;
% 
% if display==1,
% figure(1)
% hold on
% plot(x_ap)
% plot(RC,'r')
% end

x_ap0 = x_ap(:);
x_ap_mean0 = mean(x_ap0);
x_ap0 = x_ap0-x_ap_mean0;

%%

y = [];
y(:,1) = x_ap0;

x = [];
x(:,1) = y;

window_test_length = M;
ind_xtest = no_gaps_indexes(1:window_test_length);
x0 = x_ap0(ind_xtest);
lim1 = theta*mean(abs(diff(x_ap0)));
lim2 = rho*sqrt(mean(abs(diff(x0).^2)));

error1 = [];
error2 = [];

x_test = [];
buffered_RC = [];

i=0;
j=0;
iter = 0;
i_loop = 1;
j_loop = 1;

while i_loop==1;
    i=i+1;
    if i>M; break; end
    
    k=0;
    j=0;
    while j_loop ==1;
        k=k+1;
        j=j+1;
        iter = iter + 1;
        
        
        cY = [];
        covX = [];
        Ctoep  = [];
        Y = [];
        RHO = [];
        LAMBDA = [];
        PC  = [];
        RC = [];
        
        cY = y(:,i);
    
        cmp_vec = i;
        [RC,PC,C,LAMBDA,RHO] = SSA_toep(cY,M,N,cmp_vec);

        buffered_RC(:,i) = RC(:,1);
        
        

        y(:,iter+1) = y(:,iter);
        y(gaps_indexes,iter+1) = sum(buffered_RC(gaps_indexes,:),2);
        y(:,iter+1) = y(:,iter+1)-mean(y(:,iter+1));
        
        rY = y(:,end);
%         display([i j])
        error1(iter) = max(abs(y(gaps_indexes,iter+1)-y(gaps_indexes,iter)));
        disp(['Error inner loop: ' num2str(error1(iter)) ' ----> Lim: ' num2str(lim1) ' | ' num2str(i) '/' num2str(j)])
        
        if error1(iter)<lim1, break; end

        
    end


    x_test(:,i) = sum(buffered_RC(ind_xtest,:),2);

     if display ==1,
    figure(2)
    clf
    hold on
    plot(y(:,1))
    plot(y(:,iter+1))
%     
    figure(3)
    clf
    hold on
    plot(x0)
    plot(x_test(:,i))
     end
    

    error2(i+1) = sqrt(mean((x_test(:,i)-x0).^2));   
    
    if i>10,
        error_outer_loop = abs(error2(i+1)-mean(error2(i-9:i)));
        disp(['----- Error outer loop: ' num2str(error2(i+1)) ' ----> Lim: ' num2str(lim2)])
        if error2(i+1)<lim2, break; end
        if error_outer_loop<0.0001; break; end
    end
    
end

new_x = y(:,end);
new_x = new_x + x_ap_mean0;
% new_x = new_x + x_ap_mean0 + RC0;

if display==1
    figure(4)
    hold on
    plot(x_ap,'b')
    plot(new_x,'r')


%     figure(5)
%     hold on
%     plot(x0)
%     plot(x_test(:,end))
end