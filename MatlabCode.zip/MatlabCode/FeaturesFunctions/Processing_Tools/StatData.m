function [ Q1,Q2,Q3,AIQ,BMOB,TMOB,BSOB,TSOB ] = StatData( x )
%UNTITLED1 Summary of this function goes here
%   Detailed explanation goes here

Q1 = [];
Q2 = [];
Q3 = [];
AIQ = [];
BMOB = [];
TMOB = [];
BSOB = [];
TSOB = [];
    
if length(x)<3,
    return;
end

n_x = length(x);



median_x = median(x);
Q2=median_x;

x = sort(x,'ascend');

if length(x)==1,
    Q1 = x;
    Q2 = x;
    Q3 = x;
    AIQ = x;
    BMOB = x;
    TMOB = x;
    BSOB = x;
    TSOB = x;
    return;
end

p025 = 0.25 * n_x;
lp025 = floor(p025); if lp025==0, lp025=1; end
hp025 = ceil(p025);

Q1 = (x(lp025) + x(hp025))/2;

p075 = 0.75 * n_x;
lp075 = floor(p075);
hp075 = ceil(p075);

Q3 = (x(lp075) + x(hp075))/2;

AIQ = Q3 - Q1;

BMOB = Q1-1.5*AIQ;
TMOB = Q3+1.5*AIQ;

BSOB = Q1-3*AIQ;
TSOB = Q3+3*AIQ;

end
