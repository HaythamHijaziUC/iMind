function [Norm] = Filt_and_Norm(N,Fs,data)

%Butterworth filter high pass digital with cutoff frequency of 0.015 Hz
FC=0.015/(0.1592*N);
[b, a] = butter(1,FC, 'high');                             
butter_filt = filtfilt(b, a, data); 

% FILTRO FIR as low pass digital with cutoff frequency of 35 Hz
fc = 35;
order = 1;
fNorme = fc/(Fs/2);                             %normalization initial frequency
fir_baixo = fir1(order, fNorme,'low');           %low pass filter to remove noise
fir_filt = filtfilt(fir_baixo, 1, butter_filt);

%Normalizing values
Norm = Normalizacao(fir_filt);

end

