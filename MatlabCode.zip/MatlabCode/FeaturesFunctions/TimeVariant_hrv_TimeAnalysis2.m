function [T, mRR, sdnnRR, sdsdRR, rmssd, nn50RR, pnn50RR,ApEn_value,SD1,SD2] = TimeVariant_hrv_TimeAnalysis2(time,data,window_samp,jump_samp)

half_window_samp = floor(window_samp/2)-1;
N_data = length(data);

T = [];
mRR = [];
sdnnRR = [];
sdsdRR = [];
rmssd = [];
nn50RR = [];
pnn50RR = [];
ApEn_value = [];
SD1 = [];
SD2 = [];


N_res = length(1:jump_samp:N_data);

k=0;
for i=1:jump_samp:N_data-half_window_samp
    %     disp(['Iter: ' num2str(i)])
        k=k+1;
        
        mRR(k,1) = nan; 
        sdnnRR(k,1) = nan; 
        sdsdRR(k,1) = nan; 
        rmssd(k,1) = nan;

        nn50RR(k,1) = nan;
        pnn50RR(k,1) = nan;
        ApEn_value(k,1) = nan;
        SD1(k,1) = nan;
        SD2(k,1) = nan;

        
        ind_b = i-half_window_samp; 
        ind_a = i+half_window_samp; 
        
        T(k) = time(ind_a);

                
        if ind_b<1, continue; ind_b=1; end
        if ind_a>N_data, continue; ind_a=N_data; end
        
        
        
        data_i = data(ind_b:ind_a);

          
        data_i=data_i(:);
        out = hrvTimeDomain(data_i);
        mRR(k,1) = out.mean;
        sdnnRR(k,1) = out.SDNN;
        sdsdRR(k,1) = out.SDSD;
        rmssd(k,1) = out.RMSSD;
        nn50RR(k,1) = out.NN50;
        pnn50RR(k,1) = out.pNN50;
        
        hrvNONL = hrvNonLinear(data_i);
        
        ApEn_value(k,1) = hrvNONL.FApen;
        SD1(k,1) = hrvNONL.Poincare(1);
        SD2(k,1) = hrvNONL.Poincare(2);
        
        

       
%         keyboard;
        
        
end



% figure
% hold on
% plot(mRR,'k')
% plot(sdnnRR,'r')
% plot(sdsdRR,'g')
% plot(rmssd,'b')
% plot(nn50RR,'c')
% plot(pnn50RR,'m')
% 
% keyboard;
% best_order

