function [y] = quantile75(x)
y = quantile(x,0.75);
end

