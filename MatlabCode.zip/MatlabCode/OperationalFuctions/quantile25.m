function [y] = quantile25(x)
y = quantile(x,0.25);
end

