%Example script for processing one content region of one text
clear;% clear workspace 
close all;% close figures 
clc;% clean command line


%% TEXT 1
volunteerNumber1=000; %%%%%%%%%%%%%select here or manual change
volunteerNumber=string(volunteerNumber1); %%%%%%%%%%%%%select here or manual change

addpath(genpath('C:\Users\migue\Documents\MATLAB\imind\PRV_and_EDA'));  %%%%%coment
window_secs =30;%%%%%Moving Window size
path="C:\Users\migue\Desktop\empatica\";
opts = detectImportOptions(path+volunteerNumber1+"\HR.csv");%detecting of type of file
HR = table2array(readtable(path+volunteerNumber1+"\HR.csv", opts));%Heart Rate from empatica
opts2 = detectImportOptions(path+volunteerNumber1+"\EDA.csv");%detecting of type of file
EDA = table2array(readtable(path+volunteerNumber1+"\EDA.csv", opts2));%electrodermal activity


%% Script Extract timestamps for eye gaze in text zones
opts3 = detectImportOptions('C:\Users\migue\Documents\Visual Studio 2022\IMindNodeAPI\outputfiles\GazePoint.txt'); 
eyetrackers = (readtable('C:\Users\migue\Documents\Visual Studio 2022\IMindNodeAPI\outputfiles\GazePoint.txt', opts3));
opts4 = detectImportOptions("C:\Users\migue\Documents\Visual Studio 2022\IMindNodeAPI\outputfiles\scroll"+volunteerNumber+".txt");
scroll = (readtable("C:\Users\migue\Documents\Visual Studio 2022\IMindNodeAPI\outputfiles\scroll"+volunteerNumber+".txt", opts4));


%% timestamps from txt created by node (INPUT HERE)
patht='C:\Users\migue\Documents\Visual Studio 2022\IMindNodeAPI\timestamp\timestamps.txt';
opts5 = detectImportOptions(patht); 
timestampsFile = (readtable(patht, opts5));%cannot use table2array in 
t=size(timestampsFile); 
for i=1:1:(t(1))
    if( table2array(timestampsFile(i,1))==volunteerNumber1 && table2array(timestampsFile(i,3))=="start")
    TsStart=table2array(timestampsFile(i,2));
    break
    end
end
for i=1:1:(t(1))
    if(table2array(timestampsFile(i,1))==volunteerNumber1 && table2array(timestampsFile(i,3))=="firsttext")
    TsFirsttext=table2array(timestampsFile(i,2));
    break
    end
end
for i=1:1:(t(1))
    if(table2array(timestampsFile(i,1))==volunteerNumber1 && table2array(timestampsFile(i,3))=="stop")
    TsStop=table2array(timestampsFile(i,2));
    break
    end
end
TsPause='';
for i=1:1:(t(1))
    if(table2array(timestampsFile(i,1))==volunteerNumber1 && table2array(timestampsFile(i,3))=="pause")
    TsPause=table2array(timestampsFile(i,2));
    break
    end
end
TsResume='';
for i=1:1:(t(1))
    if(table2array(timestampsFile(i,1))==volunteerNumber1 && table2array(timestampsFile(i,3))=="resume")
    TsResume=table2array(timestampsFile(i,2));
    break
    end
end




%% cut scroll data downsample to 5 HZ
timestamp1=datetime(date,'Format','HH:mm:ss.SSS')+table2array(scroll(:,2));
%indexso = SC_FindTimestampindatetime(timestamp1,TsStop);
Syc_scroll=downsample( table2array(scroll(1:end,1)),2 );
Syc_scrollt=downsample( timestamp1(1:end),2 );%timestamp


%% cut eyetracker values downsample to equivalent of 5Hz
timestamp1=datetime(date,'Format','HH:mm:ss.SSS')+table2array(eyetrackers(:,3));
eyetrackY=downsample( table2array(eyetrackers(:,2)),40 );
eyetrackY=eyetrackY(4000800:end);
eyetrackYt=downsample(timestamp1,40);
eyetrackYt=eyetrackYt(4000800:end);
[indexsa,indexso] = Tobii_FindTimestampindatetime(eyetrackYt,Syc_scrollt(1),Syc_scrollt(end));
%coiso=eyetrackYt(indexsa:indexso);
eyetrackerY=downsample(eyetrackY(indexsa:indexso),22);
eyetrackerYt=downsample(eyetrackYt(indexsa:indexso),22);
ChromeTab=145;
Syc_New_eyetrackerY=zeros(size(Syc_scrollt));%scroll + eye tracker
index=0;
indexc2=1;
if TsPause~=""
    %disp("pause");
    indexsap = SC_FindTimestampindatetime(eyetrackerYt,TsPause);
    indexsop = SC_FindTimestampindatetime(eyetrackerYt,TsResume);
    t=indexsap+size(eyetrackerY)-indexsop+1;
    eyetrackerY1=zeros(t(1),1);
    eyetrackerY1(1:indexsap)=eyetrackerY(1:indexsap);
    eyetrackerY1(indexsap+1:end)=eyetrackerY(indexsop:end);
    eyetrackerY=eyetrackerY1;
    eyetrackerYt1(1:indexsap,1)=eyetrackerYt(1:indexsap);
    eyetrackerYt1(indexsap+1:t,1)=eyetrackerYt(indexsop:end);
    eyetrackerYt=eyetrackerYt1;
end


set=size(eyetrackerYt(:,1));
for c1= 1:1:(size(Syc_scrollt))
    indexc2=index+1;
    while (indexc2<=set(1))
            if(eyetrackerYt(indexc2).Hour==Syc_scrollt(c1).Hour && eyetrackerYt(indexc2).Minute==Syc_scrollt(c1).Minute)
               if( abs( eyetrackerYt(indexc2).Second - Syc_scrollt(c1).Second )<=0.1 ) 
                    index=indexc2;
                    break
                end
            end
    indexc2=indexc2+1;
    end

    Syc_New_eyetrackerY(c1)=Syc_scroll(c1)+eyetrackerY(index)+15;
    if(eyetrackerY(index)<0)
        Syc_New_eyetrackerY(c1)=70+ChromeTab;
    end
end
%save("Syc_New_eyetrackerY.mat","Syc_New_eyetrackerY")



























%% Script ----------Part 2----------
  %% 1.2 Find areas and revisits
  
%% Pixel size of div, text and tab (INPUT HERE)
ChromeTab=145;
TopDiv=100;
margin=1;
FontSize=35;
WordSpace=18;
Padding=38;
BottomDiv=50;
NumberLinesFirstParagraph=1+1+2+2; 
NumberLinesSecondParagraph=3+3; 
NumberLinesThirdParagraph=3;
FirstParagraph=ChromeTab+TopDiv+margin+WordSpace-5+(FontSize/2);
EndFirstParagraph=FirstParagraph+(NumberLinesFirstParagraph-1)*(WordSpace+FontSize)+(4-1)*Padding;
SecondParagraph=EndFirstParagraph+Padding+(WordSpace)+(FontSize/2);
EndSecondParagraph=SecondParagraph+(NumberLinesSecondParagraph-1)*(WordSpace+FontSize)+(2-1)*Padding+50;
ThirdParagraph=EndSecondParagraph+Padding+(WordSpace)+(FontSize/2);
EndThirdParagraph=ThirdParagraph+(NumberLinesThirdParagraph-1)*(WordSpace+FontSize);
TrackerTolerance=FontSize/2+WordSpace/2+15;


Syc_New_eyetrackerYarea=zeros(size(Syc_New_eyetrackerY));
for c1=1:1:(size(Syc_New_eyetrackerY))
    if Syc_New_eyetrackerY(c1)>FirstParagraph-TrackerTolerance && Syc_New_eyetrackerY(c1)<EndFirstParagraph+TrackerTolerance
        Syc_New_eyetrackerYarea(c1)=1;
    elseif Syc_New_eyetrackerY(c1)>SecondParagraph-TrackerTolerance && Syc_New_eyetrackerY(c1)<EndSecondParagraph+TrackerTolerance
        Syc_New_eyetrackerYarea(c1)=2;
    elseif Syc_New_eyetrackerY(c1)>ThirdParagraph-TrackerTolerance && Syc_New_eyetrackerY(c1)<EndThirdParagraph+TrackerTolerance
        Syc_New_eyetrackerYarea(c1)=3;
    elseif Syc_New_eyetrackerY(c1)==215
        Syc_New_eyetrackerYarea(c1)=-1;
    else
        Syc_New_eyetrackerYarea(c1)=0; 
    end
    
end




count1=0;
revisit1=0;
revisit2=0;
revisit3=0;
index1=1;
index2=1;
index3=1;
lastarea=1;   %1
countrest=0; 
count1flag=0; 
count2flag=0; 
count3flag=0; 
searchflag=1; %1
set2=size(Syc_New_eyetrackerYarea);
Syc_New_eyetrackerYarea(1)=0;
Syc_New_eyetrackerYarea(set2(1)-5)=3; %set(1)
Syc_New_eyetrackerYarea(set2(1)-4)=3; %set(1)
Syc_New_eyetrackerYarea(set2(1)-3)=3; %set(1)
Syc_New_eyetrackerYarea(set2(1)-2)=3; %set(1)
Syc_New_eyetrackerYarea(set2(1)-1)=3;
Syc_New_eyetrackerYarea(set2(1))=3;
internalcount=0;
firstindex1=[];
firstindex2=[];
firstindex3=[];
IBP1=[];IEP1=[];IBP2=[];IEP2=[];IBP3=[];IEP3=[];
IBRP1=zeros(1,5);IERP1=zeros(1,5);IBRP2=zeros(1,5);IERP2=zeros(1,5);IBRP3=zeros(1,5);IERP3=zeros(1,5);
stored=0;
for c1=2:1:(size(Syc_New_eyetrackerYarea))
  if Syc_New_eyetrackerYarea(c1)==lastarea
        count1=count1+1;
  end
    if(count1flag==1 && lastarea==1)
        if Syc_New_eyetrackerYarea(c1)==-1
            countrest=countrest+1;
            if(revisit1==0)
                if countrest>19 %2*3 
                    count1=1;
                    count1flag=0;
                    searchflag=1;
                end
            end
            if(revisit1>0)
                if countrest>10
                    count1=1;
                    count1flag=0;
                    searchflag=1;
                end
            end
        end
    elseif(count2flag==1 && lastarea==2)
        if Syc_New_eyetrackerYarea(c1)==-1
            countrest=countrest+1;
            if(revisit2==0)
                if countrest>19 %2*3
                    count1=1;
                    count2flag=0;
                    searchflag=2;
                end
            end
            if(revisit2>0)
                if countrest>10
                    count1=1;
                    count2flag=0;
                    searchflag=2;
                end
            end
        end
    elseif(count3flag==1 && lastarea==3)
        if Syc_New_eyetrackerYarea(c1)==-1
            countrest=countrest+1;
            if(revisit3==0)
                if countrest>19 %2*3
                    count1=1;
                    count3flag=0;
                    searchflag=3;
                end
            end
            if(revisit3>0)
                if countrest>10
                    count1=1;
                    count3flag=0;
                    searchflag=3;
                end
            end
        end
    end
    if Syc_New_eyetrackerYarea(c1)==1 && searchflag==1 %more
        count1flag=1;
        firstindex1=c1;
        countrest=0;
        internalcount=0;
        searchflag=0;
    elseif Syc_New_eyetrackerYarea(c1)==2 && searchflag==2 %more
        count2flag=1;
         firstindex2=c1-3;
        countrest=0;
        internalcount=0;
        searchflag=0;
    elseif Syc_New_eyetrackerYarea(c1)==3 && searchflag==3 %more
        count3flag=1;
         firstindex3=c1-3;
        countrest=0;
        internalcount=0;
        searchflag=0;
    end
    if searchflag==-2 && Syc_New_eyetrackerYarea(c1)==Syc_New_eyetrackerYarea(c1-1)
        if Syc_New_eyetrackerYarea(c1)==1
            %disp(1);
          count1flag=1;
         firstindex1=c1;
        countrest=0;
        internalcount=0;
        searchflag=0;  
        count1=2;
        lastarea=1;
        end
        if Syc_New_eyetrackerYarea(c1)==2
            %disp(2);
            count2flag=1;
         firstindex2=c1;
        countrest=0;
        internalcount=0;
        searchflag=0;
        lastarea=2;
        end
        if Syc_New_eyetrackerYarea(c1)==3
            %disp(3);
        count3flag=1;
         firstindex3=c1;
        countrest=0;
        internalcount=0;
        searchflag=0;
        lastarea=3;
        end
    end
    if Syc_New_eyetrackerYarea(c1)~=lastarea && Syc_New_eyetrackerYarea(c1)==Syc_New_eyetrackerYarea(c1-1)
            internalcount=internalcount+1;
        if internalcount==4 && stored==Syc_New_eyetrackerYarea(c1) %%%%2 
            Mcount1=count1;
            Mlastarea=lastarea;
             if Mlastarea==1 && Mcount1>=12*3 && revisit1==0 %%5*20
                %primeira visita
                revisit1=revisit1+1;
                sz=(c1-4)-(firstindex1)+index1;
                Area1(index1:sz)=Syc_scrollt(firstindex1:c1-4);
                IBP1=firstindex1;
                IEP1=c1-4;
                count1=3;
                index1=sz+1;
                countrest=0;
                internalcount=0;
                if Syc_New_eyetrackerYarea(c1)==0
                lastarea=-2;
                searchflag=-2;
                count1=0;
                else
                lastarea=Syc_New_eyetrackerYarea(c1);
                searchflag=Syc_New_eyetrackerYarea(c1);
                end
             end
             if Mlastarea==2 && Mcount1>=12*3 && revisit2==0 %%5*20
                %primeira visita
                revisit2=revisit2+1;
                sz=(c1-4)-(firstindex2)+index2;
                Area2(index2:sz)=Syc_scrollt(firstindex2:c1-4); %%(:,1)
                count1=3;
                IBP2=firstindex2;
                IEP2=c1-4;
                
                index2=sz+1;
                countrest=0;
                
                internalcount=0;
                if Syc_New_eyetrackerYarea(c1)==0
                lastarea=-2;
                searchflag=-2;
                count1=0;
                else
                lastarea=Syc_New_eyetrackerYarea(c1);
                searchflag=Syc_New_eyetrackerYarea(c1);
                end
             end
             if Mlastarea==3 && Mcount1>=12*3 && revisit3==0 %%5*20
                %primeira visita
                revisit3=revisit3+1;
                sz=(c1-4)-(firstindex3)+index3;
                Area3(index3:sz)=Syc_scrollt(firstindex3:c1-4);
                IBP3=firstindex3;
                IEP3=c1-4;
                count1=3;
               
                index3=sz+1;
                countrest=0;
                
                internalcount=0;
                if Syc_New_eyetrackerYarea(c1)==0
                lastarea=-2;
                searchflag=-2;
                count1=0;
                else
                lastarea=Syc_New_eyetrackerYarea(c1);
                searchflag=Syc_New_eyetrackerYarea(c1);
                end
             end
             if Mlastarea==1 && Mcount1>=7*3 && revisit1>0 && internalcount~=0 %%5*2
                 
                sz=(c1-4)-(firstindex1)+index1;
                Area1(index1:sz)=Syc_scrollt(firstindex1:c1-4);
                IBRP1(revisit1)=firstindex1;
                IERP1(revisit1)=c1-4;
                count1=3;
                index1=sz+1;
                revisit1=revisit1+1;
                countrest=0;
                internalcount=0;
                if Syc_New_eyetrackerYarea(c1)==0
                lastarea=-2;
                searchflag=-2;
                count1=0;
                else
                lastarea=Syc_New_eyetrackerYarea(c1);
                searchflag=Syc_New_eyetrackerYarea(c1);
                end
             end
             if Mlastarea==2 && Mcount1>=7*3 && revisit2>0 && internalcount~=0 %%5*2
                
                sz=(c1-4)-(firstindex2)+index2;
                Area2(index2:sz)=Syc_scrollt(firstindex2:c1-4);
                count1=3;
                IBRP2(revisit2)=firstindex2;
                IERP2(revisit2)=c1-4;
                
                index2=sz+1;
                countrest=0;
                revisit2=revisit2+1;
                internalcount=0;
                if Syc_New_eyetrackerYarea(c1)==0
                lastarea=-2;
                searchflag=-2;
                count1=0;
                else
                lastarea=Syc_New_eyetrackerYarea(c1);
                searchflag=Syc_New_eyetrackerYarea(c1);
                end
             end
             if Mlastarea==3 && Mcount1>=7*3 && revisit3>0 && internalcount~=0 %%5*2
                
                sz=(c1-4)-(firstindex3)+index3;
                Area3(index3:sz)=Syc_scrollt(firstindex3:c1-4);
                count1=3;
                IBRP3(revisit3)=firstindex3;
                IERP3(revisit3)=c1-4;
                revisit3=revisit3+1;
                index3=sz+1;
                countrest=0;
                internalcount=0;
                
                if Syc_New_eyetrackerYarea(c1)==0
                lastarea=-2;
                searchflag=-2;
                count1=0;
                else
                lastarea=Syc_New_eyetrackerYarea(c1);
                searchflag=Syc_New_eyetrackerYarea(c1);
                end
             end
            
        end
        if stored~=Syc_New_eyetrackerYarea(c1)
            internalcount=0;
        end
    stored=Syc_New_eyetrackerYarea(c1);
        if internalcount>=5
            searchflag=-2;
            
        end
    end
    
end
% disp("Done");
% if revisit1==0 || revisit2==0 || revisit3==0
%     disp("error: one or more content zones not found");
% elseif(revisit1>1 || revisit2>1 || revisit3>1)
%     disp("revisits happen");
% else
%     disp("revisits did not happen");
% end
V000.revisitsnumberT1R1=revisit1-1;
V000.revisitsnumberT1R2=revisit2-1;













%% 2.2 First paragraph     T1R1
TSbegin = Syc_scrollt(IBP1);
TSend = Syc_scrollt(IEP1);r=1;

 %% 2.2.1 HR
[NEWHR,NEWHRt] = ConvertUnixtoDatetime(HR,0);  
%function to find by only comparing only the hour, minute and second
indexsa = FindTimestampindatetime(NEWHRt,TSbegin);
indexso = FindTimestampindatetime(NEWHRt,TSend);
new_HR=NEWHR(indexsa:indexso);%HR cuted with the acording timestamps
ttime_T1R1=seconds(NEWHRt(indexso)-NEWHRt(indexsa));
set=indexso-indexsa+1+1;
if(revisit1>1)
  for i=1:1:length(IBRP1)
      if IBRP1(i)~=0
     TSbegin2=Syc_scrollt(IBRP1(i));
    TSend2=Syc_scrollt(IERP1(i));
    indexsa = FindTimestampindatetime(NEWHRt,TSbegin2);
    indexso = FindTimestampindatetime(NEWHRt,TSend2);
    new_HR(set:(indexso-indexsa+set),1)=NEWHR(indexsa:indexso);
    ttime_T1R1=ttime_T1R1+seconds(NEWHRt(indexso)-NEWHRt(indexsa));
    set=indexso-indexsa+1+set;
      end
  end
end
%% new
comp=0;
if ttime_T1R1<30
    comp=13;
    indexsa = FindTimestampindatetime(NEWHRt,TSbegin);
    indexso = FindTimestampindatetime(NEWHRt,TSend)+comp;
    new_HR=NEWHR(indexsa:indexso);%HR cuted with the acording timestamps
    ttime_T1R1=seconds(NEWHRt(indexso)-NEWHRt(indexsa)); 
end
%%
%all data transformation, resample and feature extraction
[SDSD_T1R1,RMSSD_T1R1,SSSDNN_T1R1,HR_T1R1,...
    number_of_windows_used_T1R1,featureswithoutwindow_T1R1,LHFratio_T1R1,ind_out,SD12_T1R1] = ...
    E4HRcsvToFeatures(new_HR,window_secs,ttime_T1R1);
%ind_out is the number of outliers
V000.RawHrT1R1=new_HR;


%% EDA
[Syc_EDA,Syc_EDAt] = ConvertUnixtoDatetime(EDA,0);
%function to find by only comparing only the hour, minute and second
indexsa = EDA_FindTimestampindatetime(Syc_EDAt,TSbegin);
indexso = EDA_FindTimestampindatetime(Syc_EDAt,TSend);
new_EDA=Syc_EDA(indexsa:indexso);%EDA cuted with the acording timestamps
ttimeE_T1R1=seconds(Syc_EDAt(indexso)-Syc_EDAt(indexsa));
[SCL_T1R1, SCR_T1R1,Peakrate_T1R1,numberofEDApeaks_T1R1] = NewE4EDAToFeatures(new_EDA,ttimeE_T1R1,r);
a=length(SCL_T1R1);b=length(SCR_T1R1);c=numberofEDApeaks_T1R1;
set=indexso-indexsa+1+1;
if(revisit1>1)
  for i=1:1:length(IBRP1)
       if IBRP1(i)~=0
     TSbegin2=Syc_scrollt(IBRP1(i));
    TSend2=Syc_scrollt(IERP1(i));
    indexsa = FindTimestampindatetime(Syc_EDAt,TSbegin2);
    indexso = FindTimestampindatetime(Syc_EDAt,TSend2);
    ttime=seconds(Syc_EDAt(indexso)-Syc_EDAt(indexsa));
    [SCL, SCR,Peakrate,numberofEDApeaks] = NewE4EDAToFeatures(Syc_EDA(indexsa:indexso),ttime,r);
    SCL_T1R1(a+1:length(SCL)+a,1)=SCL;
    a=length(SCL_T1R1);
    SCR_T1R1(b+1:length(SCR)+b,1)=SCR;
    b=length(SCR_T1R1);
    c=c+numberofEDApeaks;
    new_EDA(set:(indexso-indexsa+set),1)=Syc_EDA(indexsa:indexso);
       end
  end
end
Peakrate_T1R1=c/ttime_T1R1;
V000.RawEdaT1R1=new_EDA;
%% New
k=0;
while (Peakrate_T1R1 == 0)
    k=k+1;
    indexsa = EDA_FindTimestampindatetime(Syc_EDAt,TSbegin)-5*k;
    indexso = EDA_FindTimestampindatetime(Syc_EDAt,TSend)+comp+10*k;
    new_EDA=Syc_EDA(indexsa:indexso);%EDA cuted with the acording timestamps
    ttimeE_T1R1=seconds(Syc_EDAt(indexso)-Syc_EDAt(indexsa));
    [SCL_T1R1, SCR_T1R1,Peakrate_T1R1,numberofEDApeaks_T1R1] = NewE4EDAToFeatures(new_EDA,ttimeE_T1R1,r);
end
%% New









%% 2.2 First paragraph     T1R2
TSbegin = Syc_scrollt(IBP2);
TSend = Syc_scrollt(IEP2);r=1;

 %% 2.2.1 HR
[NEWHR,NEWHRt] = ConvertUnixtoDatetime(HR,0);  
%function to find by only comparing only the hour, minute and second
indexsa = FindTimestampindatetime(NEWHRt,TSbegin);
indexso = FindTimestampindatetime(NEWHRt,TSend)+6;
new_HR=NEWHR(indexsa:indexso);%HR cuted with the acording timestamps
ttime_T1R2=seconds(NEWHRt(indexso)-NEWHRt(indexsa));
set=indexso-indexsa+1+1;
if(revisit2>1)
  for i=1:1:length(IBRP2)
      if IBRP2(i)~=0
     TSbegin2=Syc_scrollt(IBRP2(i));
    TSend2=Syc_scrollt(IERP2(i));
    indexsa = FindTimestampindatetime(NEWHRt,TSbegin2);
    indexso = FindTimestampindatetime(NEWHRt,TSend2);
    new_HR(set:(indexso-indexsa+set),1)=NEWHR(indexsa:indexso);
    ttime_T1R2=ttime_T1R2+seconds(NEWHRt(indexso)-NEWHRt(indexsa));
    set=indexso-indexsa+1+set;
      end
  end
end
%% new
comp=0;
if ttime_T1R2<30
    comp=13;
    indexsa = FindTimestampindatetime(NEWHRt,TSbegin);
    indexso = FindTimestampindatetime(NEWHRt,TSend)+comp;
    new_HR=NEWHR(indexsa:indexso);%HR cuted with the acording timestamps
    ttime_T1R2=seconds(NEWHRt(indexso)-NEWHRt(indexsa)); 
end
%%
%all data transformation, resample and feature extraction
[SDSD_T1R2,RMSSD_T1R2,SSSDNN_T1R2,HR_T1R2,...
    number_of_windows_used_T1R2,featureswithoutwindow_T1R2,LHFratio_T1R2,ind_out,SD12_T1R2] = ...
    E4HRcsvToFeatures(new_HR,window_secs,ttime_T1R2);
%ind_out is the number of outliers
V000.RawHrT1R2=new_HR;

%% EDA
[Syc_EDA,Syc_EDAt] = ConvertUnixtoDatetime(EDA,0);
%function to find by only comparing only the hour, minute and second
indexsa = EDA_FindTimestampindatetime(Syc_EDAt,TSbegin);
indexso = EDA_FindTimestampindatetime(Syc_EDAt,TSend)+comp;
new_EDA=Syc_EDA(indexsa:indexso);%EDA cuted with the acording timestamps
ttimeE_T1R2=seconds(Syc_EDAt(indexso)-Syc_EDAt(indexsa));
[SCL_T1R2, SCR_T1R2,Peakrate_T1R2,numberofEDApeaks_T1R2] = NewE4EDAToFeatures(new_EDA,ttimeE_T1R2,r);
a=length(SCL_T1R2);b=length(SCR_T1R2);c=numberofEDApeaks_T1R2;
set=indexso-indexsa+1+1;
if(revisit2>1)
  for i=1:1:length(IBRP2)
       if IBRP2(i)~=0
     TSbegin2=Syc_scrollt(IBRP2(i));
    TSend2=Syc_scrollt(IERP2(i));
    indexsa = FindTimestampindatetime(Syc_EDAt,TSbegin2);
    indexso = FindTimestampindatetime(Syc_EDAt,TSend2);
    ttime=seconds(Syc_EDAt(indexso)-Syc_EDAt(indexsa));
    [SCL, SCR,Peakrate,numberofEDApeaks] = NewE4EDAToFeatures(Syc_EDA(indexsa:indexso),ttime,r);
    SCL_T1R2(a+1:length(SCL)+a,1)=SCL;
    a=length(SCL_T1R2);
    SCR_T1R2(b+1:length(SCR)+b,1)=SCR;
    b=length(SCR_T1R2);
    c=c+numberofEDApeaks;
    new_EDA(set:(indexso-indexsa+set),1)=Syc_EDA(indexsa:indexso);
       end
  end
end
Peakrate_T1R2=c/ttime_T1R2;
V000.RawEdaT1R2=new_EDA;


%Check for missing SCR peak
k=0;
while (Peakrate_T1R2 == 0)
    k=k+1;
    indexsa = EDA_FindTimestampindatetime(Syc_EDAt,TSbegin)-5*k;
    indexso = EDA_FindTimestampindatetime(Syc_EDAt,TSend)+comp+10*k;
    new_EDA=Syc_EDA(indexsa:indexso);%EDA cuted with the acording timestamps
    ttimeE_T1R2=seconds(Syc_EDAt(indexso)-Syc_EDAt(indexsa));
    [SCL_T1R2, SCR_T1R2,Peakrate_T1R2,numberofEDApeaks_T1R2] = NewE4EDAToFeatures(new_EDA,ttimeE_T1R2,r);
end

%Storing
V000.SDSD_T1R1=SDSD_T1R1; V000.RMSSD_T1R1=RMSSD_T1R1;V000.SSDNN_T1R1=SSSDNN_T1R1;V000.LHFratio_T1R1=LHFratio_T1R1;V000.SD12_T1R1=SD12_T1R1;V000.ttime_T1R1=ttime_T1R1;
V000.SCL_T1R1=SCL_T1R1; V000.SCR_T1R1=SCR_T1R1;V000.Peakrate_T1R1=Peakrate_T1R1;

V000.SDSD_T1R2=SDSD_T1R2; V000.RMSSD_T1R2=RMSSD_T1R2;V000.SSDNN_T1R2=SSSDNN_T1R2;V000.LHFratio_T1R2=LHFratio_T1R2;V000.SD12_T1R2=SD12_T1R2;V000.ttime_T1R2=ttime_T1R2;
V000.SCL_T1R2=SCL_T1R2; V000.SCR_T1R2=SCR_T1R2;V000.Peakrate_T1R2=Peakrate_T1R2;

save("V000")